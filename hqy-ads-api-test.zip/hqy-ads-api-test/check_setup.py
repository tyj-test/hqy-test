#!/usr/bin/env python3
"""
检查环境设置脚本
用于验证框架是否正确配置
"""
import sys
from pathlib import Path

def check_python_version():
    """检查Python版本"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print(f"❌ Python版本过低: {version.major}.{version.minor}, 需要Python 3.7+")
        return False
    print(f"✓ Python版本: {version.major}.{version.minor}.{version.micro}")
    return True

def check_module_import():
    """检查模块导入"""
    project_root = Path(__file__).parent
    sys.path.insert(0, str(project_root))
    
    try:
        from common.api_client import APIClient
        from common.auth import AuthManager
        from common.data_loader import DataLoader
        print("✓ 模块导入成功")
        return True
    except ImportError as e:
        print(f"❌ 模块导入失败: {e}")
        print("   请检查项目结构是否正确")
        return False
    except Exception as e:
        print(f"❌ 模块导入异常: {e}")
        return False

def check_dependencies():
    """检查依赖包"""
    required_packages = [
        'requests',
        'pytest',
        'yaml'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            if package == 'yaml':
                __import__('yaml')
            else:
                __import__(package)
            print(f"✓ {package} 已安装")
        except ImportError:
            print(f"❌ {package} 未安装")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n⚠ 缺少依赖包: {', '.join(missing_packages)}")
        print("   请运行: pip3 install -r requirements.txt")
        return False
    
    return True

def check_config_file():
    """检查配置文件"""
    config_file = Path(__file__).parent / 'config' / 'base_config.yaml'
    if not config_file.exists():
        print("❌ 配置文件不存在: config/base_config.yaml")
        return False
    
    print("✓ 配置文件存在")
    return True

def main():
    """主函数"""
    print("=" * 50)
    print("  接口自动化测试框架 - 环境检查")
    print("=" * 50)
    print()
    
    checks = [
        ("Python版本", check_python_version),
        ("模块导入", check_module_import),
        ("依赖包", check_dependencies),
        ("配置文件", check_config_file),
    ]
    
    results = []
    for name, check_func in checks:
        print(f"\n检查 {name}...")
        result = check_func()
        results.append((name, result))
    
    print("\n" + "=" * 50)
    print("  检查结果汇总")
    print("=" * 50)
    
    all_passed = True
    for name, result in results:
        status = "✓ 通过" if result else "❌ 失败"
        print(f"{name}: {status}")
        if not result:
            all_passed = False
    
    print()
    if all_passed:
        print("✓ 所有检查通过，环境配置正确！")
        return 0
    else:
        print("❌ 部分检查未通过，请根据上述提示修复问题")
        return 1

if __name__ == '__main__':
    sys.exit(main())

