#!/bin/bash
# 生成Allure报告脚本

echo "======================================"
echo "  生成 Allure 测试报告"
echo "======================================"
echo ""

cd "$(dirname "$0")"

# 检查allure结果目录是否存在
if [ ! -d "reports/allure" ]; then
    echo "❌ Allure结果目录不存在，请先运行测试"
    exit 1
fi

# 检查是否有测试结果
result_count=$(find reports/allure -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
if [ "$result_count" -eq 0 ]; then
    echo "❌ 未找到测试结果文件，请先运行测试"
    exit 1
fi

echo "✓ 找到 $result_count 个测试结果文件"

# 检查是否安装了allure命令行工具
if command -v allure &> /dev/null; then
    echo "✓ Allure CLI 已安装"
    echo ""
    echo "正在生成Allure报告..."
    
    # 生成报告
    allure generate reports/allure -o reports/allure-report --clean
    
    echo ""
    echo "======================================"
    echo "  报告生成完成！"
    echo "======================================"
    echo ""
    echo "报告位置: $(pwd)/reports/allure-report/index.html"
    echo ""
    echo "打开报告方式："
    echo "1. 使用浏览器打开: reports/allure-report/index.html"
    echo "2. 或运行命令: allure open reports/allure-report"
    echo ""
    
    # 询问是否打开报告
    read -p "是否现在打开报告? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if command -v open &> /dev/null; then
            open reports/allure-report/index.html
        elif command -v xdg-open &> /dev/null; then
            xdg-open reports/allure-report/index.html
        else
            echo "请手动打开: reports/allure-report/index.html"
        fi
    fi
else
    echo "⚠ Allure CLI 未安装"
    echo ""
    echo "安装Allure CLI的方式："
    echo ""
    echo "macOS (使用Homebrew):"
    echo "  brew install allure"
    echo ""
    echo "或者下载安装包："
    echo "  https://github.com/allure-framework/allure2/releases"
    echo ""
    echo "安装后，运行以下命令生成报告："
    echo "  allure generate reports/allure -o reports/allure-report --clean"
    echo "  allure open reports/allure-report"
    echo ""
    echo "当前测试结果已保存在: reports/allure/"
    echo "您可以稍后安装Allure CLI后再生成报告"
fi

