#!/bin/bash
# 运行测试并生成Allure报告的完整脚本

echo "======================================"
echo "  运行测试并生成 Allure 报告"
echo "======================================"
echo ""

cd "$(dirname "$0")"

# 运行步骤1和步骤2的测试
echo "正在运行测试..."
python3 -m pytest tests/test_flow_003.py::TestFlow003AccountAllocation::test_step1_query_ads_account_list tests/test_flow_003.py::TestFlow003AccountAllocation::test_step2_query_user_list -v -s --alluredir=reports/allure

echo ""
echo "✓ 测试执行完成"
echo ""

# 检查Allure CLI是否安装
if command -v allure &> /dev/null; then
    echo "正在生成Allure报告..."
    allure generate reports/allure -o reports/allure-report --clean
    
    echo ""
    echo "======================================"
    echo "  报告生成完成！"
    echo "======================================"
    echo ""
    echo "报告位置: $(pwd)/reports/allure-report/index.html"
    echo ""
    
    # 自动打开报告
    if command -v open &> /dev/null; then
        echo "正在打开报告..."
        open reports/allure-report/index.html
    elif command -v xdg-open &> /dev/null; then
        xdg-open reports/allure-report/index.html
    fi
else
    echo "⚠ Allure CLI 未安装，生成简单HTML报告..."
    python3 generate_simple_report.py
    echo ""
    echo "简单报告位置: $(pwd)/reports/html/simple_report.html"
    echo ""
    echo "要生成完整的Allure报告，请先安装Allure CLI:"
    echo "  brew install allure"
    echo ""
    echo "然后运行:"
    echo "  allure generate reports/allure -o reports/allure-report --clean"
    echo "  allure open reports/allure-report"
fi

