"""
数据加载模块
用于加载和管理配置文件、测试数据
"""
import yaml
import os
from pathlib import Path


class DataLoader:
    """数据加载器"""
    
    def __init__(self):
        self.base_dir = Path(__file__).parent.parent
        self.config_dir = self.base_dir / "config"
        self.config_data = {}
        self.test_data = {}
        self._load_config()
        self._load_test_data()
    
    def _load_config(self):
        """加载基础配置"""
        config_file = self.config_dir / "base_config.yaml"
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                self.config_data = yaml.safe_load(f) or {}
        else:
            raise FileNotFoundError(f"配置文件不存在: {config_file}")
    
    def _load_test_data(self):
        """加载测试数据"""
        test_data_file = self.config_dir / "test_data.yaml"
        if test_data_file.exists():
            with open(test_data_file, 'r', encoding='utf-8') as f:
                self.test_data = yaml.safe_load(f) or {}
        else:
            # 如果文件不存在，创建默认结构
            self.test_data = {
                "current_token": "",
                "test_context": {},
                "cleanup_needed": {}
            }
            self.save_test_data()
    
    def save_test_data(self):
        """保存测试数据到文件"""
        test_data_file = self.config_dir / "test_data.yaml"
        with open(test_data_file, 'w', encoding='utf-8') as f:
            yaml.dump(self.test_data, f, allow_unicode=True, default_flow_style=False)
    
    def get_config(self, key_path, default=None):
        """
        获取配置值
        :param key_path: 配置路径，如 'environments.api_base_url'
        :param default: 默认值
        :return: 配置值
        """
        keys = key_path.split('.')
        value = self.config_data
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def get_test_data(self, key_path, default=None):
        """
        获取测试数据
        :param key_path: 数据路径，如 'test_context.user_id'
        :param default: 默认值
        :return: 数据值
        """
        keys = key_path.split('.')
        value = self.test_data
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set_test_data(self, key_path, value):
        """
        设置测试数据
        :param key_path: 数据路径，如 'test_context.user_id'
        :param value: 数据值
        """
        keys = key_path.split('.')
        data = self.test_data
        for key in keys[:-1]:
            if key not in data:
                data[key] = {}
            data = data[key]
        data[keys[-1]] = value
        self.save_test_data()
    
    def clear_test_data(self):
        """清空测试数据"""
        self.test_data = {
            "current_token": "",
            "test_context": {},
            "cleanup_needed": {}
        }
        self.save_test_data()


# 全局数据加载器实例
data_loader = DataLoader()

