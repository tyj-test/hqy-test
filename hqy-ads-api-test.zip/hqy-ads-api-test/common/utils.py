"""
工具函数模块
"""
import time
import random
import string
from typing import Any, Dict, Tuple, List


def generate_timestamp() -> str:
    """生成时间戳字符串"""
    return str(int(time.time() * 1000))


def generate_random_string(length: int = 8) -> str:
    """生成随机字符串"""
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))


def generate_test_email(prefix: str = "test") -> str:
    """生成测试邮箱"""
    timestamp = generate_timestamp()
    random_str = generate_random_string(4)
    return f"{prefix}_{timestamp}_{random_str}@example.com"


def deep_merge_dict(base: Dict, update: Dict) -> Dict:
    """
    深度合并字典
    :param base: 基础字典
    :param update: 更新字典
    :return: 合并后的字典
    """
    result = base.copy()
    for key, value in update.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge_dict(result[key], value)
        else:
            result[key] = value
    return result


def format_response(response_data: Any) -> str:
    """
    格式化响应数据用于日志输出
    :param response_data: 响应数据
    :return: 格式化后的字符串
    """
    if isinstance(response_data, dict):
        return str(response_data)[:500]  # 限制长度
    return str(response_data)[:500]


def validate_response_structure(response_data: Dict, required_fields: List[str]) -> Tuple[bool, str]:
    """
    验证响应数据结构
    :param response_data: 响应数据
    :param required_fields: 必需字段列表，如 ['code', 'msg', 'data']
    :return: (是否通过, 错误信息)
    """
    if not isinstance(response_data, dict):
        return False, "响应数据不是字典类型"
    
    missing_fields = []
    for field in required_fields:
        if field not in response_data:
            missing_fields.append(field)
    
    if missing_fields:
        return False, f"缺少必需字段: {', '.join(missing_fields)}"
    
    return True, ""


def assert_response_code(response_data: Dict, expected_code: int = 0, error_msg: str = ""):
    """
    断言响应状态码
    :param response_data: 响应数据
    :param expected_code: 期望的状态码
    :param error_msg: 错误信息
    """
    actual_code = response_data.get('code')
    if actual_code != expected_code:
        msg = error_msg or f"响应状态码不匹配，期望: {expected_code}, 实际: {actual_code}"
        raise AssertionError(f"{msg}\n响应数据: {response_data}")

