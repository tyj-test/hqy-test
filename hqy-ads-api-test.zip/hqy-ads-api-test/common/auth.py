"""
认证管理模块
处理登录、token管理等功能
"""
import requests
import time
from typing import Optional
from .data_loader import data_loader
from .utils import format_response


class AuthManager:
    """认证管理器"""
    
    def __init__(self):
        self.ops_login_url = data_loader.get_config('environments.ops_login_url')
        self.username = data_loader.get_config('ops_account.username')
        self.password = data_loader.get_config('ops_account.password')
        self.timeout = data_loader.get_config('environments.timeout', 30)
        self._token = None
    
    def login(self) -> Optional[str]:
        """
        运营端登录获取token
        :return: token字符串，失败返回None
        """
        # 如果配置中没有captchaId，生成一个时间戳作为captchaId
        captcha_id = data_loader.get_config('ops_account.captchaId')
        if not captcha_id:
            captcha_id = str(int(time.time() * 1000))
        
        login_data = {
            "username": str(self.username),
            "password": str(self.password),  # 确保密码是字符串类型
            "captcha": str(data_loader.get_config('ops_account.captcha', "")),
            "captchaId": str(captcha_id)
        }
        
        try:
            response = requests.post(
                self.ops_login_url,
                json=login_data,
                timeout=self.timeout
            )
            response.raise_for_status()
            result = response.json()
            
            # 提取token（根据实际返回结构调整）
            # 可能的位置: result['data']['token'] 或 result['token'] 等
            token = None
            if isinstance(result, dict):
                # 尝试多种可能的token路径
                if 'data' in result and isinstance(result['data'], dict):
                    token = result['data'].get('token') or result['data'].get('accessToken')
                token = token or result.get('token') or result.get('accessToken')
            
            if token:
                self._token = token
                data_loader.set_test_data('current_token', token)
                print(f"✓ 登录成功，token已保存")
                return token
            else:
                print(f"✗ 登录失败，未找到token字段")
                print(f"响应数据: {format_response(result)}")
                return None
                
        except requests.exceptions.RequestException as e:
            print(f"✗ 登录请求异常: {str(e)}")
            return None
        except Exception as e:
            print(f"✗ 登录处理异常: {str(e)}")
            return None
    
    def get_token(self, force_refresh: bool = False) -> Optional[str]:
        """
        获取token，如果不存在或需要刷新则重新登录
        :param force_refresh: 是否强制刷新
        :return: token字符串
        """
        if not force_refresh:
            # 尝试从缓存获取
            cached_token = data_loader.get_test_data('current_token')
            if cached_token:
                self._token = cached_token
                return cached_token
        
        # 重新登录获取token
        return self.login()
    
    def clear_token(self):
        """清除token"""
        self._token = None
        data_loader.set_test_data('current_token', "")


# 全局认证管理器实例
auth_manager = AuthManager()

