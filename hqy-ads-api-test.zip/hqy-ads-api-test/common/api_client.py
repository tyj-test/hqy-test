"""
API客户端模块
封装HTTP请求方法
"""
import requests
from typing import Optional, Dict, Any
from common.data_loader import data_loader
from .auth import auth_manager
from .utils import format_response, assert_response_code


class APIClient:
    """API客户端"""
    
    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None):
        """
        初始化API客户端
        :param base_url: API基础地址，默认从配置读取
        :param token: 认证token，默认自动获取
        """
        self.base_url = base_url or data_loader.get_config('environments.api_base_url')
        self.timeout = data_loader.get_config('environments.timeout', 30)
        self.retry_times = data_loader.get_config('environments.retry_times', 3)
        self.session = requests.Session()
        
        # 设置token
        if token:
            self.token = token
        else:
            self.token = auth_manager.get_token()
        
        # 设置默认请求头（不包含Authorization，由_prepare_headers统一处理）
        self.session.headers.update({
            'Content-Type': 'application/json;charset=UTF-8',
            'source': 'OPERATION'  # 运营端标识
        })
    
    def update_token(self, token: str):
        """更新token"""
        self.token = token
        auth_header = token if token.startswith('Bearer ') else f'Bearer {token}'
        self.session.headers.update({'Authorization': auth_header})
    
    def _prepare_headers(self, headers: Optional[Dict] = None) -> Dict:
        """
        准备请求头
        :param headers: 额外请求头
        :return: 合并后的请求头
        """
        request_headers = {}
        if self.token:
            # 确保Authorization格式为 Bearer {token}
            auth_header = self.token if self.token.startswith('Bearer ') else f'Bearer {self.token}'
            request_headers['Authorization'] = auth_header
        
        request_headers['Content-Type'] = 'application/json;charset=UTF-8'
        request_headers['source'] = 'OPERATION'  # 运营端标识
        
        if headers:
            request_headers.update(headers)
        
        return request_headers
    
    def get(self, endpoint: str, params: Optional[Dict] = None, 
            headers: Optional[Dict] = None, **kwargs) -> requests.Response:
        """
        发送GET请求
        :param endpoint: API端点
        :param params: URL参数
        :param headers: 请求头
        :param kwargs: 其他requests参数
        :return: Response对象
        """
        url = f"{self.base_url}{endpoint}"
        request_headers = self._prepare_headers(headers)
        
        try:
            response = self.session.get(
                url,
                params=params,
                headers=request_headers,
                timeout=self.timeout,
                **kwargs
            )
            return response
        except requests.exceptions.RequestException as e:
            print(f"✗ GET请求异常: {endpoint}, 错误: {str(e)}")
            raise
    
    def post(self, endpoint: str, data: Optional[Any] = None, 
             json: Optional[Dict] = None, headers: Optional[Dict] = None,
             **kwargs) -> requests.Response:
        """
        发送POST请求
        :param endpoint: API端点
        :param data: 请求数据（form-data）
        :param json: JSON数据
        :param headers: 请求头
        :param kwargs: 其他requests参数
        :return: Response对象
        """
        url = f"{self.base_url}{endpoint}"
        request_headers = self._prepare_headers(headers)
        
        try:
            response = self.session.post(
                url,
                data=data,
                json=json,
                headers=request_headers,
                timeout=self.timeout,
                **kwargs
            )
            return response
        except requests.exceptions.RequestException as e:
            print(f"✗ POST请求异常: {endpoint}, 错误: {str(e)}")
            raise
    
    def put(self, endpoint: str, data: Optional[Any] = None,
            json: Optional[Dict] = None, headers: Optional[Dict] = None,
            **kwargs) -> requests.Response:
        """
        发送PUT请求
        :param endpoint: API端点
        :param data: 请求数据
        :param json: JSON数据
        :param headers: 请求头
        :param kwargs: 其他requests参数
        :return: Response对象
        """
        url = f"{self.base_url}{endpoint}"
        request_headers = self._prepare_headers(headers)
        
        try:
            response = self.session.put(
                url,
                data=data,
                json=json,
                headers=request_headers,
                timeout=self.timeout,
                **kwargs
            )
            return response
        except requests.exceptions.RequestException as e:
            print(f"✗ PUT请求异常: {endpoint}, 错误: {str(e)}")
            raise
    
    def delete(self, endpoint: str, headers: Optional[Dict] = None,
               **kwargs) -> requests.Response:
        """
        发送DELETE请求
        :param endpoint: API端点
        :param headers: 请求头
        :param kwargs: 其他requests参数
        :return: Response对象
        """
        url = f"{self.base_url}{endpoint}"
        request_headers = self._prepare_headers(headers)
        
        try:
            response = self.session.delete(
                url,
                headers=request_headers,
                timeout=self.timeout,
                **kwargs
            )
            return response
        except requests.exceptions.RequestException as e:
            print(f"✗ DELETE请求异常: {endpoint}, 错误: {str(e)}")
            raise
    
    def request_with_assert(self, method: str, endpoint: str, 
                           expected_code: int = 200,
                           expected_biz_code: Any = None,
                           **kwargs) -> Dict:
        """
        发送请求并断言响应
        :param method: HTTP方法
        :param endpoint: API端点
        :param expected_code: 期望的HTTP状态码
        :param expected_biz_code: 期望的业务状态码（如0或200）
        :param kwargs: 请求参数
        :return: 响应JSON数据
        """
        method_map = {
            'GET': self.get,
            'POST': self.post,
            'PUT': self.put,
            'DELETE': self.delete
        }
        
        method_func = method_map.get(method.upper())
        if not method_func:
            raise ValueError(f"不支持的HTTP方法: {method}")
        
        response = method_func(endpoint, **kwargs)
        
        # 断言HTTP状态码
        assert response.status_code == expected_code, \
            f"HTTP状态码不匹配，期望: {expected_code}, 实际: {response.status_code}\n" \
            f"响应内容: {response.text[:500]}"
        
        # 解析JSON响应
        try:
            result = response.json()
        except ValueError:
            raise ValueError(f"响应不是有效的JSON格式: {response.text[:500]}")
        
        # 断言业务状态码（如果提供了期望值）
        if expected_biz_code is not None:
            assert_response_code(result, expected_biz_code)
        
        return result

