# Allure 测试报告使用指南

## Allure 框架已集成 ✅

测试用例已经集成了 Allure 框架，包含：
- ✅ 测试步骤详细记录
- ✅ 请求/响应数据附件
- ✅ 测试结果统计
- ✅ 可视化报告

## 生成 Allure 报告

### 方式一：使用 Allure CLI（推荐，功能最完整）

#### 1. 安装 Allure CLI

**macOS (推荐使用 Homebrew)**:
```bash
brew install allure
```

**或者手动安装**:
1. 下载 Allure: https://github.com/allure-framework/allure2/releases
2. 解压并配置 PATH 环境变量

**验证安装**:
```bash
allure --version
```

#### 2. 运行测试生成结果

测试已经运行完成，结果文件保存在: `reports/allure/`

#### 3. 生成并查看报告

```bash
# 生成报告
allure generate reports/allure -o reports/allure-report --clean

# 在浏览器中打开报告
allure open reports/allure-report
```

**或者使用提供的脚本**:
```bash
./generate_allure_report.sh
```

### 方式二：使用简单HTML报告（无需安装）

如果暂时无法安装 Allure CLI，可以使用简单的HTML报告：

```bash
python3 generate_simple_report.py
```

然后打开: `reports/html/simple_report.html`

---

## 报告特性

### Allure 报告包含：

1. **测试概览**
   - 测试总数、通过、失败、跳过统计
   - 执行时间统计
   - 趋势图表

2. **详细测试步骤**
   - 每个步骤的执行状态
   - 请求参数和响应数据
   - 附件（JSON、文本等）

3. **测试分类**
   - 按 Epic、Feature、Story 分类
   - 按优先级（Severity）分类
   - 按标签（Tags）分类

4. **可视化图表**
   - 测试执行趋势
   - 通过率统计
   - 持续时间分布

---

## 当前测试结果

已完成的测试：
- ✅ 步骤1: 查询广告账户列表
- ✅ 步骤2: 查询用户列表

测试结果文件位置: `reports/allure/`

---

## 快速开始

1. **安装 Allure CLI**:
   ```bash
   brew install allure
   ```

2. **生成报告**:
   ```bash
   allure generate reports/allure -o reports/allure-report --clean
   allure open reports/allure-report
   ```

3. **查看报告**:
   浏览器会自动打开，显示完整的测试报告

---

## 报告示例

Allure 报告将包含以下内容：

- 📊 **Dashboard**: 测试执行总览
- 📋 **Suites**: 测试套件列表
- 📝 **Graphs**: 测试结果图表
- ⏱️ **Timeline**: 测试执行时间线
- 🏷️ **Behaviors**: 按功能分类的测试
- 🔍 **Packages**: 按包分类的测试

每个测试用例将显示：
- ✅ 测试步骤（Steps）
- 📎 附件（Attachments）- 包含请求参数、响应数据等
- 📊 执行时间
- 🔗 链接到相关的测试步骤

---

**提示**: 安装 Allure CLI 后，报告将更加美观和功能完整！

