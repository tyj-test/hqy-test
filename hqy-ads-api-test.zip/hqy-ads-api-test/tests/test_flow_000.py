"""
FLOW-002: 用户创建与管理流程测试用例

测试流程：
1. 获取公司列表
2. 创建用户
3. 更新用户信息
"""
import sys
import os
from pathlib import Path
import time
import random

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import pytest
import allure
import json
from common.api_client import APIClient
from common.data_loader import data_loader
from common.utils import assert_response_code, validate_response_structure


@allure.epic("FLOW-002 用户创建与管理流程")
@allure.feature("用户管理")
@pytest.mark.p0
@pytest.mark.flow
class TestFlow002UserManagement:
    """用户创建与管理流程测试"""
    
    @allure.story("获取公司列表")
    @allure.title("步骤1: 获取公司列表")
    @allure.description("获取系统中的公司列表，提取公司ID用于后续创建用户")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step1_get_company_list(self, api_client: APIClient):
        """
        步骤1: 获取公司列表
        """
        with allure.step("步骤1: 获取公司列表"):
            print("\n=== 步骤1: 获取公司列表 ===")
        
        with allure.step("构建请求参数"):
            # 构建请求参数（根据接口文档，可以传递status和companyName进行筛选）
            request_data = {}
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            # 发送请求
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/companies/allCompany',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据"):
            # 验证响应结构
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            print(f"响应数据: {result}")
            
            # 验证数据列表
            data = result.get('data')
            if data is None:
                print("⚠ 响应data字段为None，请检查接口返回")
                allure.attach(str(result), name="错误响应", attachment_type=allure.attachment_type.TEXT)
                pytest.fail(f"接口返回数据异常: {result}")
            
            assert isinstance(data, list), f"data字段不是列表类型: {type(data)}"
            assert len(data) > 0, "公司列表为空，无法继续测试"
            
            print(f"✓ 查询成功，找到 {len(data)} 个公司")
            allure.attach(f"公司数量: {len(data)}", name="查询结果统计", attachment_type=allure.attachment_type.TEXT)
        
        with allure.step("提取公司ID"):
            # 提取第一个公司的ID
            first_company = data[0]
            company_id = first_company.get('id')
            
            if company_id:
                data_loader.set_test_data('test_context.company_id', company_id)
                data_loader.set_test_data('test_context.company_name', first_company.get('name', ''))
                print(f"✓ 提取公司ID: {company_id}, 公司名称: {first_company.get('name', '')}")
                
                company_info = {
                    'companyId': company_id,
                    'companyName': first_company.get('name', '')
                }
                allure.attach(json.dumps(company_info, indent=2, ensure_ascii=False), name="公司信息", attachment_type=allure.attachment_type.JSON)
                allure.attach(f"公司ID: {company_id}", name="提取结果", attachment_type=allure.attachment_type.TEXT)
            else:
                pytest.skip("未找到可用的公司ID，请检查响应数据结构")
    
    @allure.story("创建用户")
    @allure.title("步骤2: 创建用户")
    @allure.description("创建新用户，使用唯一邮箱和随机标识")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step2_create_user(self, api_client: APIClient):
        """
        步骤2: 创建用户
        """
        with allure.step("步骤2: 创建用户"):
            print("\n=== 步骤2: 创建用户 ===")
        
        # 获取公司ID（从前置步骤）
        company_id = data_loader.get_test_data('test_context.company_id')
        if not company_id:
            pytest.skip("缺少公司ID，请先执行步骤1")
        
        with allure.step("生成用户信息"):
            # 生成唯一的邮箱和用户信息
            timestamp = int(time.time())
            random_num = random.randint(1000, 9999)
            user_email = f"testuser_{timestamp}_{random_num}@example.com"
            user_nickname = f"测试用户_{timestamp}"
            
            user_info = {
                'email': user_email,
                'nickname': user_nickname,
                'mobile': '13800138000',
                'currency': 'USD'
            }
            allure.attach(json.dumps(user_info, indent=2, ensure_ascii=False), name="生成的用户信息", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("构建请求参数"):
            # 构建创建用户请求参数
            request_data = {
                "email": user_email,
                "password": "Test123456",
                "nickname": user_nickname,
                "status": 1,
                "mobile": "13800138000",
                "currency": "USD",
                "companyStatus": 1,
                "source": 1,  # 1-自拓
                "communicationChannel": [],
                "introducerId": None,
                "officialWeb": "",
                "businessType": None,
                "cooperationStatus": None,
                "introducer": ""
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送创建请求"):
            # 发送请求
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/users/create',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证创建结果"):
            # 验证响应
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            print(f"响应数据: {result}")
            


    def test_step4_update_user(self, api_client: APIClient):
        """
        步骤4: 更新用户信息
        """
        with allure.step("步骤4: 更新用户信息"):
            print("\n=== 步骤4: 更新用户信息 ===")
        
        # 获取用户ID和原始信息

        original_email = data_loader.get_test_data('test_context.user_email')
        original_nickname = data_loader.get_test_data('test_context.user_nickname')

        
        with allure.step("构建更新请求参数"):
            # 构建更新请求参数
            # 注意：根据接口文档，更新接口需要传递所有必填字段
            updated_nickname = f"{original_nickname}_已更新"
            request_data = {
                "id": str(13122),  # 根据接口文档，id需要是string类型
                "email": original_email,  # 保持原邮箱
                "nickname": updated_nickname,
                "status": 1,
                "communicationChannel": [],
                "source": 1,
                "introducerId": None,
                "officialWeb": "",
                "companyName": original_nickname,  # 公司名称
                "businessType": None,
                "cooperationStatus": None,
                "companyStatus": 1,
                "introducer": "",
                "currency": "USD"
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送更新请求"):
            # 发送请求
            result = api_client.request_with_assert(
                method='PUT',
                endpoint='/gobestads/operation/users/update',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证更新结果"):
            # 验证响应
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            print(f"响应数据: {result}")
            print(f"✓ 更新请求已发送")
            
            # 保存更新后的昵称
            data_loader.set_test_data('test_context.updated_nickname', updated_nickname)
            
            allure.attach(f"更新后的昵称: {updated_nickname}", name="更新结果", attachment_type=allure.attachment_type.TEXT)




    # 客户端接口，放后面验证客户端校验
    # @allure.story("查询用户余额和账户")
    # @allure.title("步骤5: 查询用户余额和账户")
    # @allure.description("查询用户的余额信息和关联的广告账户")
    # @allure.severity(allure.severity_level.CRITICAL)
    # def test_step5_query_user_balance_and_accounts(self, api_client: APIClient):
    #     """
    #     步骤5: 查询用户余额和账户
    #     """
    #     with allure.step("步骤5: 查询用户余额和账户"):
    #         print("\n=== 步骤5: 查询用户余额和账户 ===")
    #
    #
    #     with allure.step("构建请求参数"):
    #         # 构建请求参数
    #         request_data = {
    #             "pageIndex": 1,
    #             "pageSize": 10,
    #             "condition": {
    #                 "account": "",
    #                 "mediaPlatform": ""
    #             }
    #         }
    #         allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
    #
    #     with allure.step("发送查询请求"):
    #         # 发送请求
    #         result = api_client.request_with_assert(
    #             method='POST',
    #             endpoint='/gobestads/operation/users/getUserBalanceAndAdsAccountPage',
    #             json=request_data,
    #             expected_code=200,
    #             expected_biz_code=None
    #         )
    #         allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
    #
    #     with allure.step("验证响应数据"):
    #         # 验证响应结构
    #         is_valid, error_msg = validate_response_structure(
    #             result,
    #             ['code', 'msg']
    #         )
    #         assert is_valid, f"响应结构验证失败: {error_msg}"
    #
    #         print(f"响应数据: {result}")
    #
    #         # 验证数据
    #         data = result.get('data')
    #         if data is None:
    #             print("⚠ 响应data字段为None，请检查接口返回")
    #             allure.attach(str(result), name="错误响应", attachment_type=allure.attachment_type.TEXT)
    #             pytest.skip(f"接口返回data为空: {result}")
    #
    #         assert isinstance(data, dict), f"data字段不是字典类型: {type(data)}"
    #
    #         # 提取用户余额和账户信息
    #         balance_info = {
    #             'totalAmount': data.get('totalAmount', '0.00'),
    #             'totalAvailableAmount': data.get('totalAvailableAmount', '0.00'),
    #             'totalFrozenAmount': data.get('totalFrozenAmount', '0.00'),
    #             'currBalance': data.get('currBalance', '0.00'),
    #             'creditLimit': data.get('creditLimit', '0'),
    #             'creditUsed': data.get('creditUsed', '0.00')
    #         }
    #
    #         account_list = data.get('list', [])
    #         print(f"✓ 查询成功")
    #         print(f"  总金额: {balance_info['totalAmount']}")
    #         print(f"  可用金额: {balance_info['totalAvailableAmount']}")
    #         print(f"  当前余额: {balance_info['currBalance']}")
    #         print(f"  关联账户数: {len(account_list)}")
    #
    #         allure.attach(json.dumps(balance_info, indent=2, ensure_ascii=False), name="余额信息", attachment_type=allure.attachment_type.JSON)
    #         allure.attach(f"账户数量: {len(account_list)}\n总金额: {balance_info['totalAmount']}", name="查询结果统计", attachment_type=allure.attachment_type.TEXT)


if __name__ == '__main__':
    # 可以直接运行此文件进行测试
    # 注意：建议使用 pytest 命令运行：pytest tests/test_flow_000.py -v -s
    pytest.main([__file__, '-v', '-s', '--tb=short'])

