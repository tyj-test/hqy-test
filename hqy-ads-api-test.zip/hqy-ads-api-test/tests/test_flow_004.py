"""
FLOW-004: 其他账户广告账户上传流程

测试流程：
1. 下载广告账号导入模版
2. 读取模板文件并填写数据
3. 上传广告账号（默认媒体 X ，可选择tt、gg和taboola还有snapchat）
4. 查询广告账号上传列表
5. 确认上传广告账户
6. 验证上传的账户
7. 修改账户类型
8. 账户分配
9. 查询分配列表
10. 获取广告账户交易列表
11. 创建账户服务费配置
12. 广告账户充值
13. 查询充值后的交易列表
14. 查询账户服务费配置
15. 更新账户服务费配置
16. 再次查询账户服务费配置
17. 手动处理交易
18. 查询客户流水交易明细
19. 获取广告账户交易列表
20. 广告账户清零
21. 查询清零后的交易列表
22. 清理测试文件
"""
import sys
import os
import time
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse, unquote, quote

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import pytest
import allure
import json
import requests
import shutil
try:
    import openpyxl
except ImportError:
    openpyxl = None
    print("⚠ 警告: openpyxl未安装，请运行: pip install openpyxl")

from common.api_client import APIClient
from common.data_loader import data_loader
from common.utils import assert_response_code, validate_response_structure


@allure.epic("FLOW-004 广告账户上传流程")
@allure.feature("账户上传")
@pytest.mark.p0
@pytest.mark.flow
class TestFlow004AccountUpload:
    """广告账户上传流程测试"""
    
    # 测试数据目录
    TEST_DATA_DIR = project_root / "test_data" / "flow_004"
    
    def setup_method(self):
        """测试前置设置"""
        # 创建测试数据目录
        self.TEST_DATA_DIR.mkdir(parents=True, exist_ok=True)
        # 初始化测试数据
        if not data_loader.get_test_data('test_context.flow_004'):
            data_loader.set_test_data('test_context.flow_004', {})
    
    @classmethod
    def teardown_class(cls):
        """类级别清理（所有测试完成后）"""
        # 清理测试文件
        try:
            test_data_dir = project_root / "test_data" / "flow_004"
            if test_data_dir.exists():
                shutil.rmtree(test_data_dir)
                print(f"✓ 已清理测试数据目录: {test_data_dir}")
        except Exception as e:
            print(f"⚠ 清理测试文件失败: {e}")
    
    def _cleanup_test_files(self):
        """清理测试生成的文件"""
        try:
            if self.TEST_DATA_DIR.exists():
                shutil.rmtree(self.TEST_DATA_DIR)
                print(f"✓ 已清理测试数据目录: {self.TEST_DATA_DIR}")
        except Exception as e:
            print(f"⚠ 清理测试文件失败: {e}")
    
    @allure.story("下载广告账号导入模版")
    @allure.title("步骤1: 下载广告账号导入模版")
    @allure.description("调用下载模版接口，下载文件并保存到测试数据文件夹")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step1_download_template(self, api_client: APIClient):
        """
        步骤1: 下载广告账号导入模版
        """
        with allure.step("步骤1: 下载广告账号导入模版"):
            print("\n=== 步骤1: 下载广告账号导入模版 ===")
        
        with allure.step("发送下载模版请求"):
            # 调用下载模版接口
            result = api_client.request_with_assert(
                method='GET',
                endpoint='/gobestads/operation/adsAccount/downloadTemplate',
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
            print(f"响应数据: {result}")
        
        with allure.step("验证响应并提取下载URL"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            # 验证HTTP状态码
            assert result.get('code') == 200, f"接口返回错误: {result}"
            
            # 提取下载URL
            data = result.get('data', {})
            download_url = data.get('url')
            assert download_url, f"响应中缺少下载URL: {result}"
            
            print(f"✓ 获取到下载URL: {download_url}")
            allure.attach(f"下载URL: {download_url}", name="下载链接", attachment_type=allure.attachment_type.TEXT)
        
        with allure.step("下载文件并保存"):
            # 下载文件（处理中文URL编码问题）
            try:
                # 处理URL中的中文编码问题
                parsed_url = urlparse(download_url)
                # 对路径部分进行URL编码处理
                encoded_path = parsed_url.path
                # 如果URL中包含中文，需要先解码再编码
                try:
                    decoded_path = unquote(encoded_path, encoding='utf-8')
                    # 重新编码路径中的非ASCII字符
                    safe_chars = '/:'
                    encoded_path = '/'.join([
                        quote(part, safe=safe_chars) if part else ''
                        for part in decoded_path.split('/')
                    ])
                except Exception as e:
                    print(f"⚠ URL编码处理警告: {e}")
                
                # 重构URL
                safe_url = f"{parsed_url.scheme}://{parsed_url.netloc}{encoded_path}"
                if parsed_url.query:
                    safe_url += f"?{parsed_url.query}"
                
                print(f"处理后的URL: {safe_url}")
                
                # 使用session来处理URL编码
                session = requests.Session()
                response = session.get(safe_url, timeout=30, allow_redirects=True)
                response.raise_for_status()
                
                # 保存文件（从URL中提取文件名，处理中文）
                template_filename = unquote(parsed_url.path.split('/')[-1], encoding='utf-8') if '/' in parsed_url.path else 'template.xlsx'
                if not template_filename or not template_filename.endswith('.xlsx'):
                    template_filename = '广告账号导入模板.xlsx'
                
                template_file_path = self.TEST_DATA_DIR / template_filename
                with open(template_file_path, 'wb') as f:
                    f.write(response.content)
                
                print(f"✓ 文件已下载并保存: {template_file_path}")
                allure.attach(f"文件路径: {template_file_path}\n文件大小: {len(response.content)} bytes", 
                            name="下载文件信息", attachment_type=allure.attachment_type.TEXT)
                
                # 保存文件路径到测试上下文
                data_loader.set_test_data('test_context.flow_004.template_file_path', str(template_file_path))
                data_loader.set_test_data('test_context.flow_004.template_filename', template_filename)
                
            except Exception as e:
                pytest.fail(f"下载文件失败: {str(e)}")
    
    @allure.story("填写模板数据")
    @allure.title("步骤2: 读取模板文件并填写数据")
    @allure.description("读取下载的模板文件，自动填写广告账号信息")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step2_fill_template(self, api_client: APIClient):
        """
        步骤2: 读取模板文件并填写数据
        """
        if openpyxl is None:
            pytest.skip("openpyxl未安装，请运行: pip install openpyxl")
        
        with allure.step("步骤2: 读取模板文件并填写数据"):
            print("\n=== 步骤2: 读取模板文件并填写数据 ===")
        
        with allure.step("获取模板文件路径"):
            template_file_path = data_loader.get_test_data('test_context.flow_004.template_file_path')
            if not template_file_path:
                pytest.skip("缺少模板文件，请先执行步骤1")
            
            template_file_path = Path(template_file_path)
            assert template_file_path.exists(), f"模板文件不存在: {template_file_path}"
            print(f"模板文件路径: {template_file_path}")
        
        with allure.step("生成广告账号ID"):
            # 生成时间戳格式：YYMMDDHHMMSS，例如 260110155630
            now = datetime.now()
            account_id = now.strftime("%y%m%d%H%M%S")
            account_name = "回归test"
            currency = "USD"
            
            print(f"生成的广告账号ID: {account_id}")
            print(f"广告账号名称: {account_name}")
            print(f"币种: {currency}")
            
            allure.attach(
                f"广告账号ID: {account_id}\n广告账号名称: {account_name}\n币种: {currency}",
                name="生成的账户信息",
                attachment_type=allure.attachment_type.TEXT
            )
            
            # 保存到测试上下文
            data_loader.set_test_data('test_context.flow_004.account_id', account_id)
            data_loader.set_test_data('test_context.flow_004.account_name', account_name)
            data_loader.set_test_data('test_context.flow_004.currency', currency)
        
        with allure.step("读取并填写Excel文件"):
            try:
                # 读取Excel文件
                workbook = openpyxl.load_workbook(template_file_path)
                worksheet = workbook.active
                
                print(f"Excel工作表名称: {worksheet.title}")
                print(f"Excel行数: {worksheet.max_row}")
                print(f"Excel列数: {worksheet.max_column}")
                
                # 查找表头行（通常在第一行）
                header_row = 1
                headers = {}
                for col in range(1, worksheet.max_column + 1):
                    cell_value = worksheet.cell(row=header_row, column=col).value
                    if cell_value:
                        headers[str(cell_value).strip()] = col
                
                print(f"表头: {headers}")
                
                # 查找需要填写的列（根据常见的列名）
                account_id_col = None
                account_name_col = None
                currency_col = None
                
                # 尝试多种可能的列名
                for key in headers.keys():
                    key_lower = key.lower()
                    if 'accountid' in key_lower or '账号id' in key_lower or 'account_id' in key_lower:
                        account_id_col = headers[key]
                    elif 'accountname' in key_lower or '账号名称' in key_lower or 'account_name' in key_lower:
                        account_name_col = headers[key]
                    elif 'currency' in key_lower or '币种' in key_lower:
                        currency_col = headers[key]
                
                # 如果没有找到，尝试使用第一、二、三列
                if not account_id_col:
                    account_id_col = 1
                if not account_name_col:
                    account_name_col = 2
                if not currency_col:
                    currency_col = 3
                
                print(f"账号ID列: {account_id_col}, 账号名称列: {account_name_col}, 币种列: {currency_col}")
                
                # 验证表头是否存在（确保第一行有内容）
                header_row_has_data = False
                for col in range(1, worksheet.max_column + 1):
                    cell_value = worksheet.cell(row=1, column=col).value
                    if cell_value and str(cell_value).strip():
                        header_row_has_data = True
                        break
                
                if not header_row_has_data:
                    # 如果表头为空，根据列位置创建表头
                    if account_id_col:
                        worksheet.cell(row=1, column=account_id_col, value="账号ID")
                    if account_name_col:
                        worksheet.cell(row=1, column=account_name_col, value="账号名称")
                    if currency_col:
                        worksheet.cell(row=1, column=currency_col, value="币种")
                    print("✓ 已创建表头（原表头为空）")
                else:
                    print("✓ 表头已存在，保留原有表头")
                
                # 填写数据（在第二行填写，第一行是表头）
                data_row = 2
                worksheet.cell(row=data_row, column=account_id_col, value=account_id)
                worksheet.cell(row=data_row, column=account_name_col, value=account_name)
                if currency_col:
                    worksheet.cell(row=data_row, column=currency_col, value=currency)
                
                print(f"✓ 数据已填写到第 {data_row} 行")
                
                # 保存文件（重要：确保文件被保存）
                filled_file_path = self.TEST_DATA_DIR / f"filled_{template_file_path.name}"
                workbook.save(filled_file_path)
                workbook.close()
                
                # 验证文件已保存
                assert filled_file_path.exists(), f"文件保存失败: {filled_file_path}"
                assert filled_file_path.stat().st_size > 0, f"保存的文件为空: {filled_file_path}"
                
                print(f"✓ 数据已填写并保存: {filled_file_path}")
                allure.attach(
                    f"填写的数据:\n账号ID: {account_id}\n账号名称: {account_name}\n币种: {currency}\n\n文件路径: {filled_file_path}",
                    name="填写结果",
                    attachment_type=allure.attachment_type.TEXT
                )
                
                # 保存填写后的文件路径
                data_loader.set_test_data('test_context.flow_004.filled_file_path', str(filled_file_path))
                
            except Exception as e:
                pytest.fail(f"填写模板文件失败: {str(e)}")
    
    @allure.story("上传广告账号")
    @allure.title("步骤3: 上传广告账号")
    @allure.description("调用上传接口，上传填写好的模板文件")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step3_upload_account(self, api_client: APIClient):
        """
        步骤3: 上传广告账号
        """
        with allure.step("步骤3: 上传广告账号"):
            print("\n=== 步骤3: 上传广告账号 ===")
        
        with allure.step("获取文件路径和媒体平台"):
            filled_file_path = data_loader.get_test_data('test_context.flow_004.filled_file_path')
            if not filled_file_path:
                pytest.skip("缺少填写后的文件，请先执行步骤2")
            
            filled_file_path = Path(filled_file_path)
            assert filled_file_path.exists(), f"文件不存在: {filled_file_path}"
            
            # 媒体平台（可扩展：x, tiktok, google, snapchat, taboola等）
            # 默认为 "x"，test_flow_004专门用于测试上传，使用"x"作为默认媒体平台
            # 注意：接口定义中mediaPlatform是字符串类型
            media_platform = 'x'  # 强制使用"x"作为默认媒体平台
            print(f"媒体平台: {media_platform}")
        
        with allure.step("构建multipart/form-data请求"):
            # 准备文件上传数据
            data = {
                'mediaPlatform': media_platform
            }
            
            allure.attach(
                f"文件: {filled_file_path.name}\n媒体平台: {media_platform}",
                name="上传参数",
                attachment_type=allure.attachment_type.TEXT
            )
            
            print(f"上传文件: {filled_file_path.name}")
            print(f"媒体平台: {media_platform}")
        
        with allure.step("发送上传请求"):
            try:
                # 准备文件（在请求时打开）
                with open(filled_file_path, 'rb') as f:
                    files = {
                        'file': (filled_file_path.name, f, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                    }
                    
                    # 对于multipart/form-data请求，需要手动构建headers
                    # 注意：不要设置Content-Type，让requests自动处理
                    upload_headers = {}
                    if api_client.token:
                        auth_header = api_client.token if api_client.token.startswith('Bearer ') else f'Bearer {api_client.token}'
                        upload_headers['Authorization'] = auth_header
                    upload_headers['source'] = 'OPERATION'
                    # 重要：不要设置Content-Type，让requests在发送files时自动设置multipart/form-data
                    
                    url = f"{api_client.base_url}/gobestads/operation/adsAccount/uploadPreview"
                    
                    # 创建一个新的session用于文件上传，避免默认headers中的Content-Type干扰
                    upload_session = requests.Session()
                    upload_session.headers.update(upload_headers)
                    # 确保不设置Content-Type，让requests自动处理
                    
                    response = upload_session.post(
                        url,
                        files=files,
                        data=data,
                        timeout=api_client.timeout
                    )
                
                assert response.status_code == 200, f"HTTP状态码错误: {response.status_code}, 响应: {response.text[:500]}"
                
                result = response.json()
                allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
                print(f"响应数据: {result}")
                
            except Exception as e:
                pytest.fail(f"上传请求失败: {str(e)}")
        
        with allure.step("验证响应并提取uploadId"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            
            # 提取uploadId
            data_obj = result.get('data', {})
            upload_id = data_obj.get('uploadId')
            assert upload_id, f"响应中缺少uploadId: {result}"
            
            total_count = data_obj.get('totalCount', 0)
            success_count = data_obj.get('successCount', 0)
            fail_count = data_obj.get('failCount', 0)
            
            print(f"✓ 上传成功！uploadId: {upload_id}")
            print(f"  总数: {total_count}, 成功: {success_count}, 失败: {fail_count}")
            
            allure.attach(
                f"uploadId: {upload_id}\n总数: {total_count}\n成功: {success_count}\n失败: {fail_count}",
                name="上传结果",
                attachment_type=allure.attachment_type.TEXT
            )
            
            # 保存uploadId到测试上下文
            data_loader.set_test_data('test_context.flow_004.upload_id', upload_id)
    
    @allure.story("查询上传列表")
    @allure.title("步骤4: 查询广告账号上传列表")
    @allure.description("根据uploadId查询上传列表")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step4_query_upload_list(self, api_client: APIClient):
        """
        步骤4: 查询广告账号上传列表
        """
        with allure.step("步骤4: 查询广告账号上传列表"):
            print("\n=== 步骤4: 查询广告账号上传列表 ===")
        
        with allure.step("获取uploadId"):
            upload_id = data_loader.get_test_data('test_context.flow_004.upload_id')
            if not upload_id:
                pytest.skip("缺少uploadId，请先执行步骤3")
            
            print(f"uploadId: {upload_id}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "uploadId": upload_id
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/queryUploadPreviewList',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            data = result.get('data', {})
            upload_list = data.get('list', [])
            total = data.get('total', 0)
            
            print(f"✓ 查询成功！总数: {total}, 列表项数: {len(upload_list)}")
            allure.attach(
                f"总数: {total}\n列表项数: {len(upload_list)}",
                name="查询结果",
                attachment_type=allure.attachment_type.TEXT
            )
    
    @allure.story("确认上传")
    @allure.title("步骤5: 确认上传广告账户")
    @allure.description("调用确认上传接口，确认上传的账户")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step5_confirm_upload(self, api_client: APIClient):
        """
        步骤5: 确认上传广告账户
        """
        with allure.step("步骤5: 确认上传广告账户"):
            print("\n=== 步骤5: 确认上传广告账户 ===")
        
        with allure.step("获取uploadId"):
            upload_id = data_loader.get_test_data('test_context.flow_004.upload_id')
            if not upload_id:
                pytest.skip("缺少uploadId，请先执行步骤3")
            
            agency = "it-test"
            print(f"uploadId: {upload_id}, agency: {agency}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "uploadId": upload_id,
                "agency": agency
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送确认请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/confirmUpload',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            
            data = result.get('data', {})
            success_count = data.get('successCount', 0)
            total_count = data.get('totalCount', 0)
            
            print(f"✓ 确认上传成功！成功数: {success_count}, 总数: {total_count}")
            allure.attach(
                f"成功数: {success_count}\n总数: {total_count}",
                name="确认结果",
                attachment_type=allure.attachment_type.TEXT
            )
    
    @allure.story("验证上传的账户")
    @allure.title("步骤6: 验证上传的账户")
    @allure.description("等待后查询账户列表，验证上传的账户是否存在")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step6_verify_account(self, api_client: APIClient):
        """
        步骤6: 验证上传的账户
        """
        with allure.step("步骤6: 验证上传的账户"):
            print("\n=== 步骤6: 验证上传的账户 ===")
        
        with allure.step("等待5秒"):
            print("等待5秒以确保账户已创建...")
            time.sleep(5)
        
        with allure.step("获取账户ID和媒体平台"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤2")
            
            # 使用"x"作为媒体平台（与步骤3保持一致）
            media_platform = 'x'  # 强制使用"x"作为默认媒体平台
            print(f"查询账户ID: {account_id}, 媒体平台: {media_platform}")
        
        with allure.step("构建查询请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "accountId": account_id,
                    "accountName": "",
                    "agency": [],
                    "accountType": [],
                    "mediaPlatform": [media_platform]
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/query',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            # 验证账户ID
            data = result.get('data', {})
            account_list = data.get('list', [])
            
            # 查找匹配的账户
            found_account = None
            for account in account_list:
                account_id_from_response = str(account.get('accountId') or account.get('id', ''))
                if account_id_from_response == account_id:
                    found_account = account
                    break
            
            assert found_account is not None, f"未找到账户ID为 {account_id} 的账户，响应列表: {account_list}"
            
            # 提取账户的主键id（用于后续修改账户类型）
            account_primary_id = found_account.get('id')
            assert account_primary_id is not None, f"账户信息中缺少主键id: {found_account}"
            
            print(f"✓ 验证成功！找到账户ID: {account_id}")
            print(f"✓ 账户主键ID: {account_primary_id}")
            
            allure.attach(
                json.dumps(found_account, indent=2, ensure_ascii=False),
                name="找到的账户信息",
                attachment_type=allure.attachment_type.JSON
            )
            allure.attach(
                f"账户ID匹配: {account_id}\n账户主键ID: {account_primary_id}",
                name="验证结果",
                attachment_type=allure.attachment_type.TEXT
            )
            
            # 保存账户主键id到测试上下文
            data_loader.set_test_data('test_context.flow_004.account_primary_id', account_primary_id)
    
    @allure.story("修改账户类型")
    @allure.title("步骤7: 修改账户类型")
    @allure.description("修改上传的账户类型，并验证修改是否成功")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step7_edit_account_type(self, api_client: APIClient):
        """
        步骤7: 修改账户类型
        """
        import random
        
        with allure.step("步骤7: 修改账户类型"):
            print("\n=== 步骤7: 修改账户类型 ===")
        
        with allure.step("获取账户主键ID"):
            account_primary_id = data_loader.get_test_data('test_context.flow_004.account_primary_id')
            if not account_primary_id:
                pytest.skip("缺少账户主键ID，请先执行步骤6")
            
            print(f"账户主键ID: {account_primary_id}")
        
        with allure.step("随机选择账户类型"):
            # 从4个账户类型中随机选择一个
            account_types = [
                'facebook_unlimited',
                'facebook_enterprise',
                'facebook_overseas',
                'facebook_green_channel'
            ]
            selected_account_type = random.choice(account_types)
            
            print(f"随机选择的账户类型: {selected_account_type}")
            allure.attach(
                f"账户主键ID: {account_primary_id}\n选择的账户类型: {selected_account_type}",
                name="修改账户类型参数",
                attachment_type=allure.attachment_type.TEXT
            )
            
            # 保存选择的账户类型到测试上下文
            data_loader.set_test_data('test_context.flow_004.selected_account_type', selected_account_type)
        
        with allure.step("构建修改账户类型请求参数"):
            request_data = {
                "ids": [int(account_primary_id)],  # 确保是整数类型
                "accountType": selected_account_type
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送修改账户类型请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/editAccountType',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证修改响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 修改账户类型成功！账户类型: {selected_account_type}")
        
        with allure.step("重新查询账户验证账户类型"):
            # 获取账户ID和媒体平台
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            media_platform = 'x'  # 与步骤6保持一致
            
            # 构建查询请求参数（与步骤6相同）
            query_request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "accountId": account_id,
                    "accountName": "",
                    "agency": [],
                    "accountType": [],
                    "mediaPlatform": [media_platform]
                }
            }
            
            # 发送查询请求
            query_result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/query',
                json=query_request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(query_result, indent=2, ensure_ascii=False), name="查询响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证账户类型是否已更新"):
            is_valid, error_msg = validate_response_structure(
                query_result,
                ['code', 'msg', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert query_result.get('code') == 200, f"查询接口返回错误: {query_result}"
            
            # 验证账户类型
            query_data = query_result.get('data', {})
            account_list = query_data.get('list', [])
            
            # 查找匹配的账户
            found_account_after_update = None
            for account in account_list:
                account_id_from_response = str(account.get('accountId') or account.get('id', ''))
                if account_id_from_response == account_id:
                    found_account_after_update = account
                    break
            
            assert found_account_after_update is not None, f"未找到账户ID为 {account_id} 的账户，响应列表: {account_list}"
            
            # 验证accountType是否与选择的类型一致
            actual_account_type = found_account_after_update.get('accountType')
            assert actual_account_type == selected_account_type, \
                f"账户类型不匹配！期望: {selected_account_type}, 实际: {actual_account_type}"
            
            print(f"✓ 验证成功！账户类型已更新为: {selected_account_type}")
            allure.attach(
                json.dumps(found_account_after_update, indent=2, ensure_ascii=False),
                name="更新后的账户信息",
                attachment_type=allure.attachment_type.JSON
            )
            allure.attach(
                f"账户类型匹配: {selected_account_type}",
                name="验证结果",
                attachment_type=allure.attachment_type.TEXT
            )
        
    @allure.story("账户分配")
    @allure.title("步骤8: 账户分配")
    @allure.description("将广告账户分配给商户，参考test_flow_001的分配逻辑")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step8_allocate_ads_account(self, api_client: APIClient):
        """
        步骤8: 账户分配
        """
        with allure.step("步骤8: 账户分配"):
            print("\n=== 步骤8: 账户分配 ===")
        
        with allure.step("获取账户主键ID和公司ID"):
            account_primary_id = data_loader.get_test_data('test_context.flow_004.account_primary_id')
            if not account_primary_id:
                pytest.skip("缺少账户主键ID，请先执行步骤6")
            
            # 固定使用2469作为companyId
            company_id = 2469
            
            print(f"账户主键ID: {account_primary_id}")
            print(f"公司ID: {company_id}")
        
        with allure.step("验证和转换数据类型"):
            # 确保账户ID是整数类型
            try:
                if isinstance(account_primary_id, int):
                    account_id_int = int(account_primary_id)
                elif isinstance(account_primary_id, (str, float)):
                    account_id_int = int(account_primary_id)
                else:
                    account_id_int = int(str(account_primary_id))
            except (ValueError, TypeError) as e:
                pytest.fail(f"账户ID转换失败: {account_primary_id}, 错误: {e}")
            
            assert isinstance(account_id_int, int), f"账户ID必须是整数类型: {account_id_int}"
            assert isinstance(company_id, int), f"公司ID必须是整数类型: {company_id}"
            
            print(f"✓ 账户ID: {account_id_int}")
            print(f"✓ 公司ID: {company_id}")
            
            allure.attach(f"账户ID: {account_id_int}\n公司ID: {company_id}", name="分配参数", attachment_type=allure.attachment_type.TEXT)
        
        with allure.step("构建请求参数"):
            request_data = {
                "ids": [account_id_int],
                "companyId": company_id
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"分配参数: ids=[{account_id_int}], companyId={company_id}")
        
        with allure.step("发送分配请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/adsAccountAllocation',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证分配结果"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            response_code = result.get('code')
            response_msg = result.get('msg', '')
            
            if response_code == 200:
                print(f"✓ 分配成功！")
                allure.attach("账户分配成功", name="分配结果", attachment_type=allure.attachment_type.TEXT)
                
                # 保存companyId到测试上下文
                data_loader.set_test_data('test_context.flow_004.company_id', company_id)
            else:
                print(f"⚠ 分配失败: code={response_code}, msg={response_msg}")
                allure.attach(f"错误信息: {response_msg}", name="分配失败", attachment_type=allure.attachment_type.TEXT)
                pytest.fail(f"账户分配失败: {response_msg}")
    
    @allure.story("查询分配列表")
    @allure.title("步骤9: 查询分配列表")
    @allure.description("查询账户分配列表，参考test_flow_001")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step9_query_allocation_list(self, api_client: APIClient):
        """
        步骤9: 查询分配列表
        """
        with allure.step("步骤9: 查询分配列表"):
            print("\n=== 步骤9: 查询分配列表 ===")
        
        with allure.step("获取公司ID"):
            company_id = data_loader.get_test_data('test_context.flow_004.company_id')
            if not company_id:
                # 如果没有保存，使用固定值2469（与步骤8保持一致）
                company_id = 2469
            
            print(f"公司ID: {company_id}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "companyId": company_id
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/queryAdsAccountAllocationList',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            if result.get('code') != 200:
                pytest.skip(f"接口返回错误: {result.get('msg')}")
            
            data = result.get('data')
            if data is None:
                pytest.skip(f"接口返回data为空: {result}")
            
            allocation_list = data.get('list', [])
            print(f"✓ 查询成功，找到 {len(allocation_list)} 条分配记录")
            allure.attach(f"分配记录数: {len(allocation_list)}", name="查询结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("获取广告账户交易列表")
    @allure.title("步骤10: 获取广告账户交易列表")
    @allure.description("查询广告账户的充值交易列表，参考test_flow_001")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step10_get_ad_recharge_list(self, api_client: APIClient):
        """
        步骤10: 获取广告账户交易列表
        """
        with allure.step("步骤10: 获取广告账户交易列表"):
            print("\n=== 步骤10: 获取广告账户交易列表 ===")
        
        with allure.step("构建请求参数"):
            # 使用固定的customerId 13042和媒体平台x
            request_data = {
                "customerId": 13042,
                "mediaPlatform": ["x"]
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: customerId=13042, mediaPlatform=['x']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            data = result.get('data')
            if data is not None:
                print(f"✓ 查询成功，获取到交易列表数据")
                allure.attach(json.dumps(data, indent=2, ensure_ascii=False), name="交易列表数据", attachment_type=allure.attachment_type.JSON)
            else:
                print("⚠ 响应data字段为None，但接口调用成功")
    
    @allure.story("创建账户服务费配置")
    @allure.title("步骤11: 创建账户服务费配置")
    @allure.description("创建账户服务费配置，为充值接口引入服务费")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step11_create_ads_account_rate(self, api_client: APIClient):
        """
        步骤11: 创建账户服务费配置
        """
        with allure.step("步骤11: 创建账户服务费配置"):
            print("\n=== 步骤11: 创建账户服务费配置 ===")
        
        with allure.step("获取账户主键ID"):
            account_primary_id = data_loader.get_test_data('test_context.flow_004.account_primary_id')
            if not account_primary_id:
                pytest.skip("缺少账户主键ID，请先执行步骤6")
            
            # 确保是整数类型
            try:
                if isinstance(account_primary_id, int):
                    account_id_int = int(account_primary_id)
                elif isinstance(account_primary_id, (str, float)):
                    account_id_int = int(account_primary_id)
                else:
                    account_id_int = int(str(account_primary_id))
            except (ValueError, TypeError) as e:
                pytest.fail(f"账户ID转换失败: {account_primary_id}, 错误: {e}")
            
            print(f"账户主键ID: {account_id_int}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "ids": [account_id_int],  # 步骤6的account_primary_id
                "rate": 10,  # 服务费率10%
                "rateStatus": 1  # 1启用
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: ids=[{account_id_int}], rate=10, rateStatus=1")
        
        with allure.step("发送创建服务费配置请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/createAdsAccountRate',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 创建账户服务费配置成功！")
            allure.attach("创建账户服务费配置成功", name="创建结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("广告账户充值")
    @allure.title("步骤12: 广告账户充值")
    @allure.description("对指定的广告账户进行充值操作，参考test_flow_001")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step12_ad_recharge(self, api_client: APIClient):
        """
        步骤11: 广告账户充值
        """
        with allure.step("步骤12: 广告账户充值"):
            print("\n=== 步骤12: 广告账户充值 ===")
        
        with allure.step("获取账户信息"):
            # 获取账户ID（步骤6中保存的accountId，不是主键id）
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            # 获取公司ID（使用2469，与步骤8保持一致）
            company_id = data_loader.get_test_data('test_context.flow_004.company_id', 2469)
            media_platform = 'x'  # 使用test_flow_004的默认媒体平台
            
            print(f"账户ID: {account_id}")
            print(f"公司ID: {company_id}")
            print(f"媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            recharge_amount = "10"  # 充值金额
            request_data = {
                "companyId": company_id,
                "totalAmount": recharge_amount,
                "adAccounts": [{
                    "accountId": str(account_id),  # 转换为字符串
                    "amount": recharge_amount,
                    "mediaPlatform": media_platform  # 使用"x"
                }]
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"充值参数: companyId={company_id}, totalAmount='{recharge_amount}', accountId='{account_id}', mediaPlatform='{media_platform}'")
            
            # 保存充值金额和媒体平台到测试上下文，用于步骤13
            data_loader.set_test_data('test_context.flow_004.recharge_amount', recharge_amount)
            data_loader.set_test_data('test_context.flow_004.recharge_media_platform', media_platform)
        
        with allure.step("发送充值请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/adRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证充值结果"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            response_code = result.get('code')
            response_msg = result.get('msg', '')
            
            if response_code == 200:
                print(f"✓ 充值成功！响应: {result}")
                allure.attach("充值成功", name="充值结果", attachment_type=allure.attachment_type.TEXT)
            else:
                # 充值接口可能有业务限制
                print(f"⚠ 充值请求失败: code={response_code}, msg={response_msg}")
                allure.attach(
                    f"错误信息: {response_msg}\n\n注意: 充值接口可能需要满足特定业务条件才能成功执行",
                    name="充值结果（业务限制）",
                    attachment_type=allure.attachment_type.TEXT
                )
                pytest.skip(
                    f"充值接口返回错误（可能由于业务限制）: code={response_code}, msg={response_msg}\n"
                    f"请求参数已验证，请检查业务条件"
                )
    
    @allure.story("查询充值后的交易列表")
    @allure.title("步骤13: 查询充值后的交易列表")
    @allure.description("查询充值后的交易列表，校验最新一条记录状态不为FAILED和actualAmount为9，参考test_flow_001")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step13_get_ad_recharge_list_after_recharge(self, api_client: APIClient):
        """
        步骤13: 查询充值后的交易列表
        """
        with allure.step("步骤13: 查询充值后的交易列表"):
            print("\n=== 步骤13: 查询充值后的交易列表 ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            media_platform = data_loader.get_test_data('test_context.flow_004.recharge_media_platform', 'x')
            
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            print(f"查询账户ID: {account_id}, 媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            # 参考test_flow_001的步骤7，查询充值类型（type不设置或为空，默认查询充值）
            request_data = {
                "pageIndex": 1,
                "pageSize": 200,
                "condition": {
                    "createdTime": [],
                    "bizNo": "",
                    "accountId": str(account_id),  # 与步骤12对应
                    "accountName": "",
                    "nickname": "",
                    "email": "",
                    "agent": [],
                    "status": [],
                    "type": "RECHARGE",  # 充值类型，可以为空
                    "mediaPlatform": [media_platform]  # 与步骤12对应
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: accountId={account_id}, mediaPlatform=['{media_platform}']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            data = result.get('data')
            if data is not None:
                transaction_list = data.get('list', [])
                if transaction_list:
                    with allure.step("校验最新一条交易记录状态（status != FAILED）和actualAmount"):
                        # 获取最新一条记录（列表第一项通常是最新的）
                        latest_transaction = transaction_list[0]
                        latest_status = latest_transaction.get('status', '')
                        latest_id = latest_transaction.get('id')
                        latest_account_id = latest_transaction.get('accountId')
                        latest_amount = latest_transaction.get('amount')
                        latest_actual_amount = latest_transaction.get('actualAmount')
                        latest_remark = latest_transaction.get('remark', '')
                        
                        print(f"最新交易记录: id={latest_id}, status={latest_status}, accountId={latest_account_id}, amount={latest_amount}, actualAmount={latest_actual_amount}")
                        
                        if latest_status == "FAILED":
                            failed_info = json.dumps({
                                'id': latest_id,
                                'status': latest_status,
                                'accountId': latest_account_id,
                                'amount': latest_amount,
                                'actualAmount': latest_actual_amount,
                                'remark': latest_remark
                            }, indent=2, ensure_ascii=False)
                            print(f"✗ 最新交易记录状态为FAILED")
                            allure.attach(failed_info, name="失败的交易记录（最新一条）", attachment_type=allure.attachment_type.JSON)
                            pytest.fail(f"最新交易记录状态为FAILED\n交易ID: {latest_id}\n账户ID: {latest_account_id}\n金额: {latest_amount}\n备注: {latest_remark}")
                        else:
                            print(f"✓ 最新交易记录状态校验通过: status={latest_status}")
                            
                            # 验证actualAmount为9（因为服务费10%，所以10-1=9）
                            if latest_actual_amount is not None:
                                # actualAmount可能是数字或字符串，需要转换比较
                                actual_amount_value = float(latest_actual_amount) if isinstance(latest_actual_amount, (str, int, float)) else latest_actual_amount
                                assert actual_amount_value == 9, f"actualAmount不匹配！期望: 9, 实际: {actual_amount_value}"
                                print(f"✓ actualAmount校验通过: {actual_amount_value}")
                            else:
                                print("⚠ 响应中缺少actualAmount字段")
                            
                            transaction_info = json.dumps({
                                'id': latest_id,
                                'status': latest_status,
                                'accountId': latest_account_id,
                                'amount': latest_amount,
                                'actualAmount': latest_actual_amount,
                                'createdTime': latest_transaction.get('createdTime', ''),
                                'completedAt': latest_transaction.get('completedAt', '')
                            }, indent=2, ensure_ascii=False)
                            allure.attach(transaction_info, name="最新交易记录信息", attachment_type=allure.attachment_type.JSON)
                            allure.attach(f"最新交易记录状态: {latest_status}\nactualAmount: {latest_actual_amount}", name="状态校验结果", attachment_type=allure.attachment_type.TEXT)
                            
                            # 提取bizNo用于步骤14
                            biz_no = latest_transaction.get('bizNo')
                            if biz_no:
                                data_loader.set_test_data('test_context.flow_004.biz_no', biz_no)
                                print(f"✓ 提取bizNo: {biz_no}")
                                allure.attach(f"bizNo: {biz_no}", name="提取的bizNo", attachment_type=allure.attachment_type.TEXT)
                else:
                    print("⚠ 交易列表为空")
                    allure.attach("交易列表为空", name="提示", attachment_type=allure.attachment_type.TEXT)
            else:
                print("⚠ 响应data字段为None，但接口调用成功")
                allure.attach("响应data字段为None", name="提示", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("查询账户服务费配置")
    @allure.title("步骤14: 查询账户服务费配置")
    @allure.description("查询账户服务费配置列表，验证rateStatus为1，并提取id用于更新")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step14_query_ads_account_rate(self, api_client: APIClient):
        """
        步骤14: 查询账户服务费配置
        """
        with allure.step("步骤14: 查询账户服务费配置"):
            print("\n=== 步骤14: 查询账户服务费配置 ===")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "accountId": "",
                    "accountName": "",
                    "mediaPlatform": ["others"]
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: mediaPlatform=['others']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/queryAdsAccountRate',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            data = result.get('data', {})
            rate_list = data.get('list', [])
            
            if rate_list:
                # 获取最新一条记录（列表第一项通常是最新的）
                latest_rate = rate_list[0]
                latest_rate_status = latest_rate.get('rateStatus')
                latest_rate_id = latest_rate.get('id')
                
                print(f"最新费率配置: id={latest_rate_id}, rateStatus={latest_rate_status}")
                
                # 验证rateStatus为1
                assert latest_rate_status == 1, f"rateStatus不匹配！期望: 1, 实际: {latest_rate_status}"
                
                print(f"✓ 验证成功！rateStatus: {latest_rate_status}")
                
                # 提取id用于步骤15
                if latest_rate_id:
                    data_loader.set_test_data('test_context.flow_004.rate_id', latest_rate_id)
                    print(f"✓ 提取费率配置ID: {latest_rate_id}")
                    allure.attach(f"费率配置ID: {latest_rate_id}", name="提取的费率配置ID", attachment_type=allure.attachment_type.TEXT)
                
                allure.attach(
                    json.dumps(latest_rate, indent=2, ensure_ascii=False),
                    name="最新费率配置",
                    attachment_type=allure.attachment_type.JSON
                )
                allure.attach(f"rateStatus: {latest_rate_status}", name="验证结果", attachment_type=allure.attachment_type.TEXT)
            else:
                pytest.fail("费率配置列表为空，无法验证rateStatus")
    
    @allure.story("更新账户服务费配置")
    @allure.title("步骤15: 更新账户服务费配置")
    @allure.description("更新账户服务费配置，将rateStatus从1改为2")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step15_update_ads_account_rate(self, api_client: APIClient):
        """
        步骤15: 更新账户服务费配置
        """
        with allure.step("步骤15: 更新账户服务费配置"):
            print("\n=== 步骤15: 更新账户服务费配置 ===")
        
        with allure.step("获取费率配置ID"):
            rate_id = data_loader.get_test_data('test_context.flow_004.rate_id')
            if not rate_id:
                pytest.skip("缺少费率配置ID，请先执行步骤14")
            
            # 确保是整数类型
            try:
                if isinstance(rate_id, int):
                    rate_id_int = int(rate_id)
                elif isinstance(rate_id, (str, float)):
                    rate_id_int = int(rate_id)
                else:
                    rate_id_int = int(str(rate_id))
            except (ValueError, TypeError) as e:
                pytest.fail(f"费率配置ID转换失败: {rate_id}, 错误: {e}")
            
            print(f"费率配置ID: {rate_id_int}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "ids": [rate_id_int],  # 步骤14提取的id
                "rate": 10,  # 费率保持10%
                "rateStatus": 2  # 2禁用
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: ids=[{rate_id_int}], rate=10, rateStatus=2")
        
        with allure.step("发送更新服务费配置请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/updateAdsAccountRate',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 更新账户服务费配置成功！")
            allure.attach("更新账户服务费配置成功", name="更新结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("再次查询账户服务费配置")
    @allure.title("步骤16: 再次查询账户服务费配置")
    @allure.description("再次查询账户服务费配置，验证rateStatus已更新为2")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step16_query_ads_account_rate_again(self, api_client: APIClient):
        """
        步骤16: 再次查询账户服务费配置
        """
        with allure.step("步骤16: 再次查询账户服务费配置"):
            print("\n=== 步骤16: 再次查询账户服务费配置 ===")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "accountId": "",
                    "accountName": "",
                    "mediaPlatform": ["others"]
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: mediaPlatform=['others']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/adsAccount/queryAdsAccountRate',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            data = result.get('data', {})
            rate_list = data.get('list', [])
            
            if rate_list:
                # 获取最新一条记录（列表第一项通常是最新的）
                latest_rate = rate_list[0]
                latest_rate_status = latest_rate.get('rateStatus')
                
                print(f"最新费率配置rateStatus: {latest_rate_status}")
                
                # 验证rateStatus为2（已更新）
                assert latest_rate_status == 2, f"rateStatus不匹配！期望: 2, 实际: {latest_rate_status}"
                
                print(f"✓ 验证成功！rateStatus已更新为: {latest_rate_status}")
                
                allure.attach(
                    json.dumps(latest_rate, indent=2, ensure_ascii=False),
                    name="最新费率配置",
                    attachment_type=allure.attachment_type.JSON
                )
                allure.attach(f"rateStatus: {latest_rate_status} (已更新)", name="验证结果", attachment_type=allure.attachment_type.TEXT)
            else:
                pytest.fail("费率配置列表为空，无法验证rateStatus")
    
    @allure.story("手动处理交易")
    @allure.title("步骤17: 手动处理交易")
    @allure.description("使用步骤13提取的bizNo调用手动处理接口")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step17_manual_processing(self, api_client: APIClient):
        """
        步骤17: 手动处理交易
        """
        with allure.step("步骤17: 手动处理交易"):
            print("\n=== 步骤17: 手动处理交易 ===")
        
        with allure.step("获取bizNo"):
            biz_no = data_loader.get_test_data('test_context.flow_004.biz_no')
            if not biz_no:
                pytest.skip("缺少bizNo，请先执行步骤13")
            
            print(f"bizNo: {biz_no}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "bizNos": [biz_no],
                "type": "SUCCESS",
                "remark": "接口自动化执行数据"
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: bizNos=['{biz_no}'], type='SUCCESS', remark='接口自动化执行数据'")
        
        with allure.step("发送手动处理请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/manualProcessing',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 手动处理成功！")
            allure.attach("手动处理成功", name="处理结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("查询客户流水交易明细")
    @allure.title("步骤18: 查询客户流水交易明细")
    @allure.description("查询客户流水交易明细，验证最新一条数据的amount为-10.00")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step18_list_transfer_details(self, api_client: APIClient):
        """
        步骤18: 查询客户流水交易明细
        """
        with allure.step("步骤18: 查询客户流水交易明细"):
            print("\n=== 步骤18: 查询客户流水交易明细 ===")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "nickname": "",
                    "userId": 13042,
                    "transactionReason": [],
                    "createdTime": []
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: userId=13042")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listTransferDetails',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            
            data = result.get('data', {})
            transaction_list = data.get('list', [])
            
            if transaction_list:
                # 获取最新一条记录（列表第一项通常是最新的）
                latest_transaction = transaction_list[0]
                latest_amount = latest_transaction.get('amount')
                latest_transactionReason= latest_transaction.get('transactionReason')
                
                print(f"最新交易记录amount: {latest_amount}")
                
                assert latest_amount == "-10.00", f"最新交易记录amount不匹配！期望: -10.00, 实际: {latest_amount}"
                assert latest_transactionReason == "AdAccountRecharge", f"最新交易记录变动原因不匹配！期望: AdAccountRecharge, 实际: {latest_transactionReason}"
                print(f"✓ 验证成功！最新交易记录amount: {latest_amount}")
                print(f"✓ 验证成功！最新交易记录transactionReason: {latest_transactionReason}")

                allure.attach(
                    json.dumps(latest_transaction, indent=2, ensure_ascii=False),
                    name="最新交易记录",
                    attachment_type=allure.attachment_type.JSON
                )
                allure.attach(f"amount: {latest_amount}", name="验证结果", attachment_type=allure.attachment_type.TEXT)
            else:
                pytest.fail("交易列表为空，无法验证amount")
    
    @allure.story("获取广告账户交易列表")
    @allure.title("步骤19: 获取广告账户交易列表")
    @allure.description("查询广告账户的充值交易列表，参考test_flow_001")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step19_get_ad_recharge_list(self, api_client: APIClient):
        """
        步骤19: 获取广告账户交易列表
        """
        with allure.step("步骤19: 获取广告账户交易列表"):
            print("\n=== 步骤19: 获取广告账户交易列表 ===")
        
        with allure.step("构建请求参数"):
            # 参考test_flow_001的步骤5，使用customerId和媒体平台
            request_data = {
                "customerId": 13042,
                "mediaPlatform": ["x"]
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: customerId=13042, mediaPlatform=['x']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            data = result.get('data')
            if data is not None:
                print(f"✓ 查询成功，获取到交易列表数据")
                allure.attach(json.dumps(data, indent=2, ensure_ascii=False), name="交易列表数据", attachment_type=allure.attachment_type.JSON)
            else:
                print("⚠ 响应data字段为None，但接口调用成功")
    
    @allure.story("再次广告账户充值")
    @allure.title("步骤19a: 再次广告账户充值")
    @allure.description("再次对指定的广告账户进行充值操作，用于失败场景测试")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step19a_ad_recharge_again(self, api_client: APIClient):
        """
        步骤19a: 再次广告账户充值
        """
        with allure.step("步骤19a: 再次广告账户充值"):
            print("\n=== 步骤19a: 再次广告账户充值 ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            company_id = data_loader.get_test_data('test_context.flow_004.company_id', 2469)
            media_platform = 'x'
            
            print(f"账户ID: {account_id}")
            print(f"公司ID: {company_id}")
            print(f"媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            recharge_amount = "10"
            request_data = {
                "companyId": company_id,
                "totalAmount": recharge_amount,
                "adAccounts": [{
                    "accountId": str(account_id),
                    "amount": recharge_amount,
                    "mediaPlatform": media_platform
                }]
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"充值参数: companyId={company_id}, totalAmount='{recharge_amount}', accountId='{account_id}', mediaPlatform='{media_platform}'")
            
            # 保存充值金额和媒体平台到测试上下文，用于步骤19c
            data_loader.set_test_data('test_context.flow_004.recharge_amount_19a', recharge_amount)
            data_loader.set_test_data('test_context.flow_004.recharge_media_platform_19a', media_platform)
        
        with allure.step("发送充值请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/adRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证充值结果"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            response_code = result.get('code')
            response_msg = result.get('msg', '')
            
            if response_code == 200:
                print(f"✓ 充值成功！响应: {result}")
                allure.attach("充值成功", name="充值结果", attachment_type=allure.attachment_type.TEXT)
            else:
                print(f"⚠ 充值请求失败: code={response_code}, msg={response_msg}")
                allure.attach(
                    f"错误信息: {response_msg}\n\n注意: 充值接口可能需要满足特定业务条件才能成功执行",
                    name="充值结果（业务限制）",
                    attachment_type=allure.attachment_type.TEXT
                )
                pytest.skip(
                    f"充值接口返回错误（可能由于业务限制）: code={response_code}, msg={response_msg}\n"
                    f"请求参数已验证，请检查业务条件"
                )
    
    @allure.story("查询充值后的交易列表（用于失败场景）")
    @allure.title("步骤19b_pre: 查询充值后的交易列表（提取bizNo）")
    @allure.description("查询充值后的交易列表，提取bizNo用于失败场景的手动处理")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step19b_pre_get_recharge_list_for_fail(self, api_client: APIClient):
        """
        步骤19b_pre: 查询充值后的交易列表（提取bizNo）
        """
        with allure.step("步骤19b_pre: 查询充值后的交易列表（提取bizNo）"):
            print("\n=== 步骤19b_pre: 查询充值后的交易列表（提取bizNo） ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            media_platform = data_loader.get_test_data('test_context.flow_004.recharge_media_platform_19a', 'x')
            
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            print(f"查询账户ID: {account_id}, 媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 200,
                "condition": {
                    "createdTime": [],
                    "bizNo": "",
                    "accountId": str(account_id),
                    "accountName": "",
                    "nickname": "",
                    "email": "",
                    "agent": [],
                    "status": [],
                    "type": "RECHARGE",
                    "mediaPlatform": [media_platform]
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("提取bizNo"):
            data = result.get('data')
            if data is not None:
                transaction_list = data.get('list', [])
                if transaction_list:
                    latest_transaction = transaction_list[0]
                    biz_no = latest_transaction.get('bizNo')
                    if biz_no:
                        data_loader.set_test_data('test_context.flow_004.biz_no_19b', biz_no)
                        print(f"✓ 提取bizNo: {biz_no}")
                        allure.attach(f"bizNo: {biz_no}", name="提取的bizNo（用于失败场景）", attachment_type=allure.attachment_type.TEXT)
                    else:
                        pytest.fail("未找到bizNo")
                else:
                    pytest.fail("交易列表为空，无法提取bizNo")
            else:
                pytest.fail("响应data字段为None，无法提取bizNo")
    
    @allure.story("手动处理交易（失败场景）")
    @allure.title("步骤19b: 手动处理交易（失败场景）")
    @allure.description("使用步骤19a提取的bizNo调用手动处理接口，type为FAIL")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step19b_manual_processing_fail(self, api_client: APIClient):
        """
        步骤19b: 手动处理交易（失败场景）
        """
        with allure.step("步骤19b: 手动处理交易（失败场景）"):
            print("\n=== 步骤19b: 手动处理交易（失败场景） ===")
        
        with allure.step("获取bizNo"):
            biz_no = data_loader.get_test_data('test_context.flow_004.biz_no_19b')
            if not biz_no:
                pytest.skip("缺少bizNo，请先执行步骤19b_pre")
            
            print(f"bizNo: {biz_no}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "bizNos": [biz_no],
                "type": "FAIL",
                "remark": "接口自动化执行失败数据"
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: bizNos=['{biz_no}'], type='FAIL', remark='接口自动化执行失败数据'")
        
        with allure.step("发送手动处理请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/manualProcessing',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 手动处理（失败场景）成功！")
            allure.attach("手动处理（失败场景）成功", name="处理结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("查询充值后的交易列表（失败场景验证）")
    @allure.title("步骤19c: 查询充值后的交易列表（失败场景验证）")
    @allure.description("查询充值后的交易列表，校验最新一条记录status为FAILED")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step19c_get_ad_recharge_list_fail(self, api_client: APIClient):
        """
        步骤19c: 查询充值后的交易列表（失败场景验证）
        """
        with allure.step("步骤19c: 查询充值后的交易列表（失败场景验证）"):
            print("\n=== 步骤19c: 查询充值后的交易列表（失败场景验证） ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            media_platform = data_loader.get_test_data('test_context.flow_004.recharge_media_platform_19a', 'x')
            
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            print(f"查询账户ID: {account_id}, 媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 200,
                "condition": {
                    "createdTime": [],
                    "bizNo": "",
                    "accountId": str(account_id),
                    "accountName": "",
                    "nickname": "",
                    "email": "",
                    "agent": [],
                    "status": [],
                    "type": "",
                    "mediaPlatform": [media_platform]
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据（status为FAILED）"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            data = result.get('data')
            if data is not None:
                transaction_list = data.get('list', [])
                if transaction_list:
                    latest_transaction = transaction_list[0]
                    latest_status = latest_transaction.get('status', '')
                    
                    print(f"最新交易记录status: {latest_status}")
                    
                    # 验证status为FAILED
                    assert latest_status == "FAILED", f"status不匹配！期望: FAILED, 实际: {latest_status}"
                    
                    print(f"✓ 验证成功！status为FAILED: {latest_status}")
                    
                    transaction_info = json.dumps({
                        'id': latest_transaction.get('id'),
                        'status': latest_status,
                        'accountId': latest_transaction.get('accountId'),
                        'amount': latest_transaction.get('amount'),
                        'createdTime': latest_transaction.get('createdTime', ''),
                        'completedAt': latest_transaction.get('completedAt', '')
                    }, indent=2, ensure_ascii=False)
                    allure.attach(transaction_info, name="最新交易记录信息（FAILED）", attachment_type=allure.attachment_type.JSON)
                    allure.attach(f"status: {latest_status}", name="验证结果", attachment_type=allure.attachment_type.TEXT)
                else:
                    pytest.fail("交易列表为空，无法验证status")
            else:
                pytest.fail("响应data字段为None，无法验证status")
    
    @allure.story("广告账户清零")
    @allure.title("步骤20: 广告账户清零")
    @allure.description("对指定的广告账户进行清零操作，参考test_flow_001")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step20_ad_clear(self, api_client: APIClient):
        """
        步骤20: 广告账户清零
        """
        with allure.step("步骤20: 广告账户清零"):
            print("\n=== 步骤20: 广告账户清零 ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            # 获取公司ID（使用2469，与步骤8保持一致）
            company_id = data_loader.get_test_data('test_context.flow_004.company_id', 2469)
            media_platform = 'x'  # 使用test_flow_004的默认媒体平台
            
            print(f"账户ID: {account_id}")
            print(f"公司ID: {company_id}")
            print(f"媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            # 参考test_flow_001的步骤10，清零接口不需要totalAmount和amount字段
            request_data = {
                "companyId": company_id,
                "adAccounts": [{
                    "accountId": str(account_id),  # 转换为字符串
                    "mediaPlatform": media_platform  # 使用"x"
                }]
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"清零参数: companyId={company_id}, accountId='{account_id}', mediaPlatform='{media_platform}'")
        
        with allure.step("发送清零请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/adClear',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证清零结果"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            response_code = result.get('code')
            response_msg = result.get('msg', '')
            
            if response_code == 200:
                print(f"✓ 清零成功！响应: {result}")
                allure.attach("清零成功", name="清零结果", attachment_type=allure.attachment_type.TEXT)
            else:
                # 清零接口可能有业务限制
                print(f"⚠ 清零请求失败: code={response_code}, msg={response_msg}")
                allure.attach(
                    f"错误信息: {response_msg}\n\n注意: 清零接口可能需要满足特定业务条件才能成功执行",
                    name="清零结果（业务限制）",
                    attachment_type=allure.attachment_type.TEXT
                )
                pytest.skip(
                    f"清零接口返回错误（可能由于业务限制）: code={response_code}, msg={response_msg}\n"
                    f"请求参数已验证，请检查业务条件"
                )
    
    @allure.story("查询清零后的交易列表")
    @allure.title("步骤21: 查询清零后的交易列表")
    @allure.description("查询清零后的交易列表，校验最新一条记录状态不为FAILED，参考test_flow_001")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step21_get_ad_clear_list(self, api_client: APIClient):
        """
        步骤21: 查询清零后的交易列表
        """
        with allure.step("步骤21: 查询清零后的交易列表"):
            print("\n=== 步骤21: 查询清零后的交易列表 ===")
        
        with allure.step("获取账户信息"):
            account_id = data_loader.get_test_data('test_context.flow_004.account_id')
            media_platform = 'x'  # 与步骤20对应
            
            if not account_id:
                pytest.skip("缺少账户ID，请先执行步骤6")
            
            print(f"查询账户ID: {account_id}, 媒体平台: {media_platform}")
        
        with allure.step("构建请求参数"):
            # 参考test_flow_001的步骤11，查询清零类型（type设置为CLEAR）
            request_data = {
                "pageIndex": 1,
                "pageSize": 200,
                "condition": {
                    "createdTime": [],
                    "bizNo": "",
                    "accountId": str(account_id),  # 与步骤20对应
                    "accountName": "",
                    "nickname": "",
                    "email": "",
                    "agent": [],
                    "status": [],
                    "type": "CLEAR",  # 清零类型
                    "mediaPlatform": [media_platform]  # 与步骤16对应
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: accountId={account_id}, type=CLEAR, mediaPlatform=['{media_platform}']")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listAdRecharge',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应数据"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            data = result.get('data')
            if data is not None:
                transaction_list = data.get('list', [])
                if transaction_list:
                    with allure.step("校验最新一条交易记录状态（status != FAILED）"):
                        # 获取最新一条记录（列表第一项通常是最新的）
                        latest_transaction = transaction_list[0]
                        latest_status = latest_transaction.get('status', '')
                        latest_id = latest_transaction.get('id')
                        latest_account_id = latest_transaction.get('accountId')
                        latest_amount = latest_transaction.get('amount')
                        latest_remark = latest_transaction.get('remark', '')
                        
                        print(f"最新交易记录: id={latest_id}, status={latest_status}, accountId={latest_account_id}, amount={latest_amount}")
                        
                        if latest_status == "FAILED":
                            failed_info = json.dumps({
                                'id': latest_id,
                                'status': latest_status,
                                'accountId': latest_account_id,
                                'amount': latest_amount,
                                'remark': latest_remark
                            }, indent=2, ensure_ascii=False)
                            print(f"✗ 最新交易记录状态为FAILED")
                            allure.attach(failed_info, name="失败的交易记录（最新一条）", attachment_type=allure.attachment_type.JSON)
                            pytest.fail(f"最新交易记录状态为FAILED\n交易ID: {latest_id}\n账户ID: {latest_account_id}\n金额: {latest_amount}\n备注: {latest_remark}")
                        else:
                            print(f"✓ 最新交易记录状态校验通过: status={latest_status}")
                            transaction_info = json.dumps({
                                'id': latest_id,
                                'status': latest_status,
                                'accountId': latest_account_id,
                                'amount': latest_amount,
                                'createdTime': latest_transaction.get('createdTime', ''),
                                'completedAt': latest_transaction.get('completedAt', '')
                            }, indent=2, ensure_ascii=False)
                            allure.attach(transaction_info, name="最新交易记录信息", attachment_type=allure.attachment_type.JSON)
                            allure.attach(f"最新交易记录状态: {latest_status}", name="状态校验结果", attachment_type=allure.attachment_type.TEXT)
                            
                            # 提取bizNo用于步骤22
                            biz_no = latest_transaction.get('bizNo')
                            if biz_no:
                                data_loader.set_test_data('test_context.flow_004.biz_no_21', biz_no)
                                print(f"✓ 提取bizNo: {biz_no}")
                                allure.attach(f"bizNo: {biz_no}", name="提取的bizNo（用于步骤22）", attachment_type=allure.attachment_type.TEXT)
                else:
                    print("⚠ 交易列表为空")
                    allure.attach("交易列表为空", name="提示", attachment_type=allure.attachment_type.TEXT)
            else:
                print("⚠ 响应data字段为None，但接口调用成功")
                allure.attach("响应data字段为None", name="提示", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("手动处理交易（清零场景）")
    @allure.title("步骤22: 手动处理交易（清零场景）")
    @allure.description("使用步骤21提取的bizNo调用手动处理接口，用于清零场景")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_step22_manual_processing_clear(self, api_client: APIClient):
        """
        步骤22: 手动处理交易（清零场景）
        """
        with allure.step("步骤22: 手动处理交易（清零场景）"):
            print("\n=== 步骤22: 手动处理交易（清零场景） ===")
        
        with allure.step("获取bizNo"):
            biz_no = data_loader.get_test_data('test_context.flow_004.biz_no_21')
            if not biz_no:
                pytest.skip("缺少bizNo，请先执行步骤21")
            
            print(f"bizNo: {biz_no}")
        
        with allure.step("构建请求参数"):
            request_data = {
                "bizNos": [biz_no],
                "type": "SUCCESS",
                "amount": "1",
                "remark": "测试数据"
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: bizNos=['{biz_no}'], type='SUCCESS', amount='1', remark='测试数据'")
        
        with allure.step("发送手动处理请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/manualProcessing',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            assert result.get('msg') == 'success' or result.get('code') == 200, f"接口返回非success: {result}"
            
            print(f"✓ 手动处理（清零场景）成功！")
            allure.attach("手动处理（清零场景）成功", name="处理结果", attachment_type=allure.attachment_type.TEXT)
    
    @allure.story("查询客户流水交易明细（清零场景）")
    @allure.title("步骤23: 查询客户流水交易明细（清零场景）")
    @allure.description("查询客户流水交易明细，验证最新一条数据的transactionReason为AdAccountClear，amount为1.00")
    @allure.severity(allure.severity_level.NORMAL)
    def test_step23_list_transfer_details_clear(self, api_client: APIClient):
        """
        步骤23: 查询客户流水交易明细（清零场景）
        """
        with allure.step("步骤23: 查询客户流水交易明细（清零场景）"):
            print("\n=== 步骤23: 查询客户流水交易明细（清零场景） ===")
        
        with allure.step("构建请求参数"):
            request_data = {
                "pageIndex": 1,
                "pageSize": 20,
                "condition": {
                    "nickname": "",
                    "userId": 13042,
                    "transactionReason": [],
                    "createdTime": []
                }
            }
            allure.attach(json.dumps(request_data, indent=2, ensure_ascii=False), name="请求参数", attachment_type=allure.attachment_type.JSON)
            print(f"请求参数: userId=13042")
        
        with allure.step("发送查询请求"):
            result = api_client.request_with_assert(
                method='POST',
                endpoint='/gobestads/operation/wallet/listTransferDetails',
                json=request_data,
                expected_code=200,
                expected_biz_code=None
            )
            allure.attach(json.dumps(result, indent=2, ensure_ascii=False), name="响应数据", attachment_type=allure.attachment_type.JSON)
        
        with allure.step("验证响应"):
            is_valid, error_msg = validate_response_structure(
                result,
                ['code', 'msg', 'data']
            )
            assert is_valid, f"响应结构验证失败: {error_msg}"
            
            assert result.get('code') == 200, f"接口返回错误: {result}"
            
            data = result.get('data', {})
            transaction_list = data.get('list', [])
            
            if transaction_list:
                # 获取最新一条记录（列表第一项通常是最新的）
                latest_transaction = transaction_list[0]
                latest_amount = latest_transaction.get('amount')
                latest_transaction_reason = latest_transaction.get('transactionReason')
                
                print(f"最新交易记录amount: {latest_amount}, transactionReason: {latest_transaction_reason}")
                
                assert latest_amount == "1.00", f"最新交易记录amount不匹配！期望: 1.00, 实际: {latest_amount}"
                assert latest_transaction_reason == "AdAccountClear", f"最新交易记录transactionReason不匹配！期望: AdAccountClear, 实际: {latest_transaction_reason}"
                
                print(f"✓ 验证成功！最新交易记录amount: {latest_amount}")
                print(f"✓ 验证成功！最新交易记录transactionReason: {latest_transaction_reason}")
                
                allure.attach(
                    json.dumps(latest_transaction, indent=2, ensure_ascii=False),
                    name="最新交易记录",
                    attachment_type=allure.attachment_type.JSON
                )
                allure.attach(f"amount: {latest_amount}\ntransactionReason: {latest_transaction_reason}", name="验证结果", attachment_type=allure.attachment_type.TEXT)
            else:
                pytest.fail("交易列表为空，无法验证amount和transactionReason")
        
        with allure.step("清理测试文件"):
            # 所有步骤完成后清理测试文件
            self._cleanup_test_files()


if __name__ == '__main__':
    # 可以直接运行此文件进行测试
    # 注意：建议使用 pytest 命令运行：pytest tests/test_flow_004.py -v -s
    pytest.main([__file__, '-v', '-s', '--tb=short'])

