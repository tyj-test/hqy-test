"""
pytest配置文件
定义全局fixtures和配置
"""
import sys
from pathlib import Path

# 确保项目根目录在Python路径中
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import pytest
import allure
from common.api_client import APIClient
from common.auth import auth_manager
from common.data_loader import data_loader


@pytest.fixture(scope="session")
def api_client():
    """
    全局API客户端fixture
    session级别，整个测试会话只创建一次
    """
    with allure.step("初始化API客户端"):
        # 确保已登录获取token
        token = auth_manager.get_token()
        if not token:
            pytest.fail("无法获取登录token，请检查登录配置")
        
        client = APIClient(token=token)
        allure.attach("API客户端初始化成功", name="初始化信息", attachment_type=allure.attachment_type.TEXT)
        yield client
        
        # 测试结束后的清理工作可以在这里进行
        print("\n测试会话结束，执行清理工作...")


@pytest.fixture(scope="function")
def clean_api_client():
    """
    独立的API客户端fixture
    function级别，每个测试函数都创建新的客户端
    """
    token = auth_manager.get_token()
    if not token:
        pytest.fail("无法获取登录token，请检查登录配置")
    
    client = APIClient(token=token)
    return client


@pytest.fixture(scope="session", autouse=True)
def setup_test_session():
    """
    测试会话初始化
    在测试开始前执行登录等准备工作
    """
    import allure
    allure.dynamic.label("framework", "pytest")
    allure.dynamic.label("language", "python")
    
    print("\n=== 测试会话初始化 ===")
    token = auth_manager.get_token()
    if token:
        print(f"✓ Token获取成功")
        allure.attach("登录成功，Token已获取", name="登录状态", attachment_type=allure.attachment_type.TEXT)
    else:
        print(f"✗ Token获取失败，请检查配置")
        allure.attach("登录失败，Token获取失败", name="登录状态", attachment_type=allure.attachment_type.TEXT)
    
    yield
    
    # 测试会话结束后的清理
    print("\n=== 测试会话结束 ===")


def pytest_configure(config):
    """pytest配置钩子"""
    # 注册自定义标记
    config.addinivalue_line(
        "markers", "p0: P0级别测试用例（核心功能）"
    )
    config.addinivalue_line(
        "markers", "p1: P1级别测试用例（重要功能）"
    )
    config.addinivalue_line(
        "markers", "flow: 业务流程测试"
    )


# def pytest_html_report_title(report):
#     """修改HTML报告标题"""
#     report.title = "接口自动化测试报告"


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """
    测试结果钩子
    用于捕获测试结果，可以在失败时截图或记录日志
    """
    outcome = yield
    rep = outcome.get_result()
    
    # 可以在测试失败时执行一些操作
    if rep.when == "call" and rep.failed:
        # 例如：记录失败信息、截图等
        pass

