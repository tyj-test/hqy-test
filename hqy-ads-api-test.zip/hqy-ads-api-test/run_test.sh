#!/bin/bash
# 测试运行脚本

echo "======================================"
echo "  接口自动化测试框架 - 运行脚本"
echo "======================================"
echo ""

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到Python3，请先安装Python3"
    exit 1
fi

echo "✓ Python版本: $(python3 --version)"

# 检查依赖是否安装
if ! python3 -c "import pytest" &> /dev/null; then
    echo "⚠ 依赖未安装，正在安装..."
    pip3 install -r requirements.txt
fi

echo "✓ 依赖检查完成"
echo ""

# 检查配置文件
if [ ! -f "config/base_config.yaml" ]; then
    echo "❌ 配置文件不存在: config/base_config.yaml"
    exit 1
fi

echo "✓ 配置文件检查完成"
echo ""

# 运行测试
echo "开始运行测试..."
echo ""

# 根据参数决定运行方式
case "$1" in
    flow003)
        echo "运行 FLOW-003: 广告账户分配流程"
        pytest tests/test_flow_003.py -v -s
        ;;
    all)
        echo "运行所有测试"
        pytest -v
        ;;
    p0)
        echo "运行P0级别测试"
        pytest -m p0 -v
        ;;
    html)
        echo "运行测试并生成HTML报告"
        pytest --html=reports/html/report.html --self-contained-html -v
        echo ""
        echo "报告已生成: reports/html/report.html"
        ;;
    allure)
        echo "运行测试并生成Allure报告"
        pytest --alluredir=reports/allure -v
        echo ""
        echo "生成Allure报告: allure serve reports/allure"
        ;;
    *)
        echo "用法: ./run_test.sh [flow003|all|p0|html|allure]"
        echo ""
        echo "选项:"
        echo "  flow003  - 运行FLOW-003测试用例"
        echo "  all      - 运行所有测试"
        echo "  p0       - 运行P0级别测试"
        echo "  html     - 运行测试并生成HTML报告"
        echo "  allure   - 运行测试并生成Allure报告"
        exit 1
        ;;
esac

