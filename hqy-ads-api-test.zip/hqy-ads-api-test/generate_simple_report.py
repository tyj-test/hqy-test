#!/usr/bin/env python3
"""
简单的Allure报告查看器
如果未安装Allure CLI，可以使用这个脚本查看测试结果
"""
import json
import os
from pathlib import Path
from datetime import datetime


def read_attachment_content(allure_dir, attachment_source):
    """读取附件文件的实际内容"""
    attachment_path = allure_dir / attachment_source
    if not attachment_path.exists():
        return None, None
    
    try:
        with open(attachment_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 判断是否为JSON文件
        if attachment_source.endswith('.json'):
            try:
                data = json.loads(content)
                return json.dumps(data, indent=2, ensure_ascii=False), 'json'
            except:
                return content, 'text'
        else:
            return content, 'text'
    except Exception as e:
        return f"读取附件失败: {str(e)}", 'error'


def read_allure_results(allure_dir):
    """读取Allure测试结果，并加载附件内容"""
    results = []
    allure_dir = Path(allure_dir)
    
    for file_path in allure_dir.glob("*-result.json"):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
                # 处理每个步骤的附件
                for step in data.get('steps', []):
                    attachments = step.get('attachments', [])
                    for attachment in attachments:
                        source = attachment.get('source')
                        if source:
                            content, content_type = read_attachment_content(allure_dir, source)
                            # 将内容添加到attachment对象中
                            attachment['_content'] = content
                            attachment['_content_type'] = content_type
                
                results.append(data)
        except Exception as e:
            print(f"读取文件失败 {file_path}: {e}")
    return results


def generate_html_report(results, output_file):
    """生成简单的HTML报告"""
    html_content = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>测试报告 - FLOW-003</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .header .meta {
            opacity: 0.9;
            font-size: 14px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .summary-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .summary-card .value {
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }
        .summary-card.passed .value { color: #10b981; }
        .summary-card.failed .value { color: #ef4444; }
        .summary-card.skipped .value { color: #f59e0b; }
        .test-case {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .test-case h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .test-case.passed { border-left: 4px solid #10b981; }
        .test-case.failed { border-left: 4px solid #ef4444; }
        .test-case.skipped { border-left: 4px solid #f59e0b; }
        .status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .status.passed { background: #d1fae5; color: #065f46; }
        .status.failed { background: #fee2e2; color: #991b1b; }
        .status.skipped { background: #fef3c7; color: #92400e; }
        .step {
            background: #f9fafb;
            border-left: 3px solid #e5e7eb;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .step h4 {
            color: #4b5563;
            margin-bottom: 10px;
            font-size: 14px;
        }
        .attachment {
            background: #f3f4f6;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
            border: 1px solid #e5e7eb;
        }
        .attachment pre {
            margin: 0;
            white-space: pre-wrap;
            word-wrap: break-word;
            max-height: 600px;
            overflow-y: auto;
            font-family: 'Monaco', 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.5;
            background: white;
            padding: 12px;
            border-radius: 4px;
            border: 1px solid #d1d5db;
        }
        .attachment pre::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        .attachment pre::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        .attachment pre::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        .attachment pre::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .attachment-title {
            font-weight: bold;
            color: #6b7280;
            margin-bottom: 8px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .attachment-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: normal;
            background: #e5e7eb;
            color: #4b5563;
        }
        .attachment-badge.json { background: #dbeafe; color: #1e40af; }
        .attachment-badge.text { background: #f3f4f6; color: #374151; }
        .duration {
            color: #9ca3af;
            font-size: 12px;
        }
        .empty {
            text-align: center;
            padding: 40px;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 接口自动化测试报告</h1>
            <div class="meta">
                <div>测试流程: FLOW-003 广告账户分配流程</div>
                <div>生成时间: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</div>
            </div>
        </div>
        
        <div class="summary">
            <div class="summary-card passed">
                <h3>通过</h3>
                <div class="value" id="passed-count">0</div>
            </div>
            <div class="summary-card failed">
                <h3>失败</h3>
                <div class="value" id="failed-count">0</div>
            </div>
            <div class="summary-card skipped">
                <h3>跳过</h3>
                <div class="value" id="skipped-count">0</div>
            </div>
            <div class="summary-card">
                <h3>总计</h3>
                <div class="value" id="total-count">0</div>
            </div>
        </div>
        
        <div id="test-cases">
            <!-- 测试用例将在这里动态生成 -->
        </div>
    </div>
    
    <script>
        const results = """ + json.dumps(results, ensure_ascii=False, indent=2) + """;
        
        let passed = 0, failed = 0, skipped = 0;
        
        results.forEach(test => {
            const status = test.status || 'unknown';
            if (status === 'passed') passed++;
            else if (status === 'failed') failed++;
            else if (status === 'skipped') skipped++;
        });
        
        document.getElementById('passed-count').textContent = passed;
        document.getElementById('failed-count').textContent = failed;
        document.getElementById('skipped-count').textContent = skipped;
        document.getElementById('total-count').textContent = results.length;
        
        const container = document.getElementById('test-cases');
        
        results.forEach(test => {
            const status = test.status || 'unknown';
            const name = test.name || '未知测试';
            const steps = test.steps || [];
            
            let html = `
                <div class="test-case ${status}">
                    <h2>${escapeHtml(name)}</h2>
                    <span class="status ${status}">${getStatusText(status)}</span>
                    <div class="duration">执行时间: ${(test.stop - test.start) / 1000 || 0} 秒</div>
            `;
            
            steps.forEach(step => {
                html += `
                    <div class="step">
                        <h4>${escapeHtml(step.name || '步骤')}</h4>
                        ${step.attachments ? step.attachments.map(att => {
                            const content = att._content || att.source || '无内容';
                            const contentType = att._content_type || 'text';
                            const badgeClass = contentType === 'json' ? 'json' : 'text';
                            const badgeText = contentType === 'json' ? 'JSON' : contentType === 'error' ? '错误' : '文本';
                            
                            return `
                                <div class="attachment">
                                    <div class="attachment-title">
                                        ${escapeHtml(att.name || '附件')}
                                        <span class="attachment-badge ${badgeClass}">${badgeText}</span>
                                    </div>
                                    <pre>${escapeHtml(content)}</pre>
                                </div>
                            `;
                        }).join('') : ''}
                    </div>
                `;
            });
            
            html += '</div>';
            container.innerHTML += html;
        });
        
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function getStatusText(status) {
            const map = {
                'passed': '✅ 通过',
                'failed': '❌ 失败',
                'skipped': '⏭ 跳过',
                'broken': '⚠️ 中断'
            };
            return map[status] || status;
        }
    </script>
</body>
</html>
    """
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✓ 简单HTML报告已生成: {output_file}")


def main():
    allure_dir = Path(__file__).parent / "reports" / "allure"
    output_file = Path(__file__).parent / "reports" / "html" / "simple_report.html"
    
    if not allure_dir.exists():
        print(f"❌ Allure结果目录不存在: {allure_dir}")
        return
    
    results = read_allure_results(allure_dir)
    
    if not results:
        print("❌ 未找到测试结果文件")
        return
    
    print(f"✓ 找到 {len(results)} 个测试结果")
    
    # 确保输出目录存在
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    generate_html_report(results, output_file)
    print(f"\n报告已生成: {output_file}")
    print("可以在浏览器中打开查看")


if __name__ == '__main__':
    main()

